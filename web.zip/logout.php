<?php
// Đảm bảo session được start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'manage_access.php';

// Debug
error_log("Logout attempt for user: " . ($_SESSION['user_id'] ?? 'unknown'));

logout_user();

header("Location: login.php?message=" . urlencode("You have logged out successfully."));
exit;
