<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Database Dashboard</title>
  <link rel="stylesheet" href="styles.css" />
  <style>

    main .dashboard-form {
      background-color: #222;
      border-radius: 10px;
      padding: 30px 40px;
      width: 90%;
      max-width: 700px;
      margin-top: 30px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    }

    main .dashboard-form h2 {
      text-align: center;
      color: #d32f2f;
      margin-bottom: 25px;
    }

    main .dashboard-form label {
      font-size: 1.1em;
      margin-bottom: 10px;
    }

    main .dashboard-form select {
      background-color: #333;
      color: #fff;
      font-size: 1.2em;
      padding: 12px;
      border: 1px solid #555;
    }

    main .dashboard-form button {
      font-size: 1.1em;
      padding: 12px;
    }
  </style>
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <section class="dashboard-form">
      <h2>DATABASE DASHBOARD</h2>
      <!-- Trả về tiếng Anh -->
      <p style="text-align: center; margin-bottom: 25px; color: #ccc;">
        Select your table: .
      </p>

      <form action="view_table.php" method="GET">

        <label for="table_select">Choose Table:</label>
        <select name="table_name" id="table_select" required>

          <option value="" disabled selected>-- Choose Your Table --</option>
          <option value="accounts">accounts</option>
          <option value="archers">archers</option>
          <option value="classes">classes</option>
          <option value="competitions">competitions</option>
          <option value="competition_results">competition_results</option>
          <option value="equipment">equipment</option>
          <option value="equivalent_rounds">equivalent_rounds</option>
          <option value="practice_score">practice_score</option>
          <option value="ranges">ranges</option>
          <option value="rounds">rounds</option>
          <option value="scores">scores</option>
          <option value="score_details">score_details</option>
          <option value="staging_scores">staging_scores</option>
        </select>

        <button type="submit">See Data</button>
      </form>
    </section>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>