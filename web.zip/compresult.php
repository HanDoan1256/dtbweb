<?php
require_once 'connection.php';

// Lấy danh sách competitions cho dropdown
$competitions_query = "
    SELECT c.*, r.name as round_name 
    FROM competitions c 
    JOIN rounds r ON c.base_round_id = r.round_id 
    ORDER BY c.date DESC
";
$competitions_result = $conn->query($competitions_query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Archery Management — Competition Results</title>
  <link rel="stylesheet" href="styles.css" />
</head>

<body>
  <?php include 'header.inc'; ?>
  <main>
    <section id="competition-results" aria-labelledby="comp-title">
      <h1 id="comp-title">Competition Results</h1>

      <h2>View All Competitions</h2>

      <?php
      if ($competitions_result && $competitions_result->num_rows > 0) {
        echo '<div style="overflow-x: auto;">';
        echo '<table border="1" style="border-collapse: collapse; width: 100%; margin: 20px 0;">';
        echo '<thead style="background-color: #f2f2f2;">';
        echo '<tr>';
        echo '<th>Competition Name</th>';
        echo '<th>Date</th>';
        echo '<th>Base Round</th>';
        echo '<th>Type</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        while ($comp = $competitions_result->fetch_assoc()) {
          $championship_badge = $comp['is_championship'] ? ' 🏆 Championship' : 'Regular';
          $championship_class = $comp['is_championship'] ? 'style="background-color: #fff3cd;"' : '';

          echo '<tr ' . $championship_class . '>';
          echo '<td><strong>' . htmlspecialchars($comp['name']) . '</strong></td>';
          echo '<td>' . $comp['date'] . '</td>';
          echo '<td>' . htmlspecialchars($comp['round_name']) . '</td>';
          echo '<td>' . $championship_badge . '</td>';
          echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
      } else {
        echo '<p>No competitions found.</p>';
      }
      ?>

      <h2>See Ranks & Scores</h2>

      <!-- Dropdown chọn competition -->
      <form method="GET" action="" style="margin: 20px 0;">
        <label for="view_results"><strong>Select Competition to View Results:</strong></label>
        <select id="view_results" name="view_results" onchange="this.form.submit()" style="padding: 8px; margin-left: 10px;">
          <option value="">-- Choose a Competition --</option>
          <?php
          // Reset pointer và hiển thị dropdown
          $competitions_result->data_seek(0);
          while ($comp = $competitions_result->fetch_assoc()) {
            $selected = (isset($_GET['view_results']) && $_GET['view_results'] == $comp['comp_id']) ? 'selected' : '';
            $display_name = htmlspecialchars($comp['name']) . ' (' . $comp['date'] . ')';
            if ($comp['is_championship']) {
              $display_name .= ' 🏆';
            }
            echo '<option value="' . $comp['comp_id'] . '" ' . $selected . '>' . $display_name . '</option>';
          }
          ?>
        </select>
        <noscript>
          <button type="submit" style="padding: 8px 15px; margin-left: 10px;">View Results</button>
        </noscript>
      </form>

      <?php
      // Hiển thị kết quả chi tiết khi chọn competition từ dropdown
      if (isset($_GET['view_results']) && !empty($_GET['view_results'])) {
        $comp_id = $_GET['view_results'];

        // Lấy thông tin competition
        $comp_query = "SELECT * FROM competitions WHERE comp_id = ?";
        $comp_stmt = $conn->prepare($comp_query);
        $comp_stmt->bind_param("i", $comp_id);
        $comp_stmt->execute();
        $comp_result = $comp_stmt->get_result();
        $competition = $comp_result->fetch_assoc();

        if ($competition) {
          echo '<div style="background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px;">';
          echo '<h3>Results for: ' . htmlspecialchars($competition['name']) . '</h3>';
          echo '<p><strong>Date:</strong> ' . $competition['date'] . ' | ';
          echo '<strong>Type:</strong> ' . ($competition['is_championship'] ? '🏆 Championship' : 'Regular Competition') . '</p>';

          // Lấy kết quả competition
          $results_query = "
                  SELECT 
                      cr.rank,
                      a.name as archer_name,
                      s.total_score,
                      cls.name as class_name,
                      e.name as equipment_name,
                      r.name as round_name
                  FROM competition_results cr
                  INNER JOIN scores s ON cr.score_id = s.score_id
                  INNER JOIN archers a ON s.archer_id = a.archer_id
                  INNER JOIN classes cls ON a.class_id = cls.class_id
                  INNER JOIN equipment e ON s.equipment_id = e.equipment_id
                  INNER JOIN rounds r ON s.round_id = r.round_id
                  WHERE cr.comp_id = ?
                  ORDER BY cr.rank ASC, s.total_score DESC
              ";

          $results_stmt = $conn->prepare($results_query);
          $results_stmt->bind_param("i", $comp_id);
          $results_stmt->execute();
          $results_result = $results_stmt->get_result();

          if ($results_result->num_rows > 0) {
            echo '<table border="1" style="border-collapse: collapse; width: 100%;">';
            echo '<thead style="background-color: #e9ecef;">';
            echo '<tr>';
            echo '<th>Rank</th>';
            echo '<th>Archer</th>';
            echo '<th>Class</th>';
            echo '<th>Equipment</th>';
            echo '<th>Round</th>';
            echo '<th>Score</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            while ($result = $results_result->fetch_assoc()) {
              $rank_display = '';
              if ($result['rank'] == 1) {
                $rank_display = '🥇 ' . $result['rank'];
              } elseif ($result['rank'] == 2) {
                $rank_display = '🥈 ' . $result['rank'];
              } elseif ($result['rank'] == 3) {
                $rank_display = '🥉 ' . $result['rank'];
              } else {
                $rank_display = $result['rank'];
              }

              echo '<tr>';
              echo '<td style="text-align: center; font-weight: bold;">' . $rank_display . '</td>';
              echo '<td>' . htmlspecialchars($result['archer_name']) . '</td>';
              echo '<td>' . htmlspecialchars($result['class_name']) . '</td>';
              echo '<td>' . htmlspecialchars($result['equipment_name']) . '</td>';
              echo '<td>' . htmlspecialchars($result['round_name']) . '</td>';
              echo '<td style="text-align: center; font-weight: bold;">' . $result['total_score'] . '</td>';
              echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
          } else {
            echo '<p>No results available for this competition yet.</p>';

            // Hiển thị scores có thể tham gia competition này
            echo '<div style="background: #e9ecef; padding: 15px; margin: 15px 0; border-radius: 5px;">';
            echo '<h4>Available Scores for This Competition</h4>';

            $available_scores_query = "
                      SELECT 
                          s.score_id,
                          a.name as archer_name,
                          s.total_score,
                          r.name as round_name,
                          s.datetime
                      FROM scores s
                      INNER JOIN archers a ON s.archer_id = a.archer_id
                      INNER JOIN rounds r ON s.round_id = r.round_id
                      WHERE s.score_id NOT IN (
                          SELECT score_id FROM competition_results WHERE comp_id = ?
                      )
                      ORDER BY s.datetime DESC
                      LIMIT 10
                  ";

            $available_stmt = $conn->prepare($available_scores_query);
            $available_stmt->bind_param("i", $comp_id);
            $available_stmt->execute();
            $available_result = $available_stmt->get_result();

            if ($available_result->num_rows > 0) {
              echo '<p><em>These scores can be added to the competition:</em></p>';
              echo '<table border="1" style="border-collapse: collapse; width: 100%; font-size: 0.9em;">';
              echo '<tr style="background-color: #f8f9fa;">';
              echo '<th>Archer</th><th>Round</th><th>Score</th><th>Date</th>';
              echo '</tr>';

              while ($score = $available_result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($score['archer_name']) . '</td>';
                echo '<td>' . htmlspecialchars($score['round_name']) . '</td>';
                echo '<td style="text-align: center;">' . $score['total_score'] . '</td>';
                echo '<td>' . date('M j, Y', strtotime($score['datetime'])) . '</td>';
                echo '</tr>';
              }
              echo '</table>';
            } else {
              echo '<p>No available scores to add to this competition.</p>';
            }

            $available_stmt->close();
            echo '</div>';
          }

          $results_stmt->close();
          $comp_stmt->close();
          echo '</div>';
        } else {
          echo '<p style="color: red;">Competition not found.</p>';
        }
      } else {
        echo '<p>Select a competition from the dropdown above to view detailed results.</p>';
      }

      $conn->close();
      ?>
    </section>
  </main>
  <?php include 'footer.inc'; ?>
  <script>
    document.getElementById('year').textContent = new Date().getFullYear();
  </script>
</body>

</html>