<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archery Management — Personal Bests</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <?php
    include 'header.inc';
    include 'connection.php';

    // Lấy archer_id từ session
    $user_id = $_SESSION['user_id'] ?? '';
    $archer_id = null;

    if ($user_id) {
        $stmt = $conn->prepare("SELECT archer_id FROM accounts WHERE username = ? OR archer_id = ?");
        $stmt->bind_param("ss", $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $archer_id = $row['archer_id'];
        }
        $stmt->close();
    }

    // Lấy Personal Bests của archer
    $personal_bests = [];
    if ($archer_id) {
        $query = "SELECT 
                    r.name as round_name,
                    r.possible_score,
                    MAX(ps.total_score) as personal_best,
                    COUNT(ps.practice_scoreID) as attempts
                  FROM practice_score ps
                  JOIN rounds r ON ps.round_id = r.round_id
                  WHERE ps.archer_id = ?
                  GROUP BY r.round_id, r.name, r.possible_score
                  ORDER BY r.name";

        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $archer_id);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $personal_bests[] = $row;
        }
        $stmt->close();
    }

    // Lấy Club Bests (highest scores từ tất cả archers)
    $club_bests = [];
    $club_query = "SELECT 
                    r.name as round_name,
                    MAX(ps.total_score) as club_best,
                    a.name as best_archer
                  FROM practice_score ps
                  JOIN rounds r ON ps.round_id = r.round_id
                  JOIN archers a ON ps.archer_id = a.archer_id
                  GROUP BY r.round_id, r.name, a.name
                  ORDER BY r.name";

    $club_result = $conn->query($club_query);
    while ($row = $club_result->fetch_assoc()) {
        $club_bests[$row['round_name']] = $row;
    }
    ?>

    <main>
        <section id="personal-bests" aria-labelledby="pb-title">
            <h1 id="pb-title">Personal Bests</h1>

            <?php if (empty($personal_bests)): ?>
                <p>No scores recorded yet. <a href="practicescore.php">Submit your first score!</a></p>
            <?php else: ?>
                <h2>Your Personal Bests</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Round</th>
                            <th>Your PB</th>
                            <th>Possible Score</th>
                            <th>Attempts</th>
                            <th>Club Best</th>
                            <th>Best Archer</th>
                            <th>Difference</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($personal_bests as $pb): ?>
                            <?php
                            $club_best = $club_bests[$pb['round_name']] ?? null;
                            $difference = $club_best ? $club_best['club_best'] - $pb['personal_best'] : null;
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pb['round_name']); ?></td>
                                <td><strong><?php echo $pb['personal_best']; ?></strong></td>
                                <td><?php echo $pb['possible_score']; ?></td>
                                <td><?php echo $pb['attempts']; ?></td>
                                <td>
                                    <?php if ($club_best): ?>
                                        <strong><?php echo $club_best['club_best']; ?></strong>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($club_best): ?>
                                        <?php echo htmlspecialchars($club_best['best_archer']); ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($difference !== null): ?>
                                        <?php if ($difference > 0): ?>
                                            -<?php echo $difference; ?>
                                        <?php elseif ($difference === 0): ?>
                                            Tied!
                                        <?php else: ?>
                                            +<?php echo abs($difference); ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <h2>Statistics</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Statistic</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $total_rounds = count($personal_bests);
                        $total_attempts = array_sum(array_column($personal_bests, 'attempts'));
                        $avg_pb = $total_rounds > 0 ? array_sum(array_column($personal_bests, 'personal_best')) / $total_rounds : 0;
                        $best_pb = $total_rounds > 0 ? max(array_column($personal_bests, 'personal_best')) : 0;
                        ?>
                        <tr>
                            <td>Rounds Completed</td>
                            <td><strong><?php echo $total_rounds; ?></strong></td>
                        </tr>
                        <tr>
                            <td>Total Attempts</td>
                            <td><strong><?php echo $total_attempts; ?></strong></td>
                        </tr>
                        <tr>
                            <td>Average Personal Best</td>
                            <td><strong><?php echo round($avg_pb, 1); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Highest Personal Best</td>
                            <td><strong><?php echo $best_pb; ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>

    <?php include 'footer.inc'; ?>
</body>

</html>