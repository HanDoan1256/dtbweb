<?php
require_once 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Championship Management</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Championship Results</h1>

    <?php
    $query = "
        SELECT 
            c.name AS competition_name,
            a.name AS archer_name,
            s.total_score AS score,
            cr.rank AS rank,
            cls.name AS class_name,
            e.name AS equipment_name
        FROM competition_results cr
        INNER JOIN competitions c ON cr.comp_id = c.comp_id
        INNER JOIN scores s ON cr.score_id = s.score_id
        INNER JOIN archers a ON s.archer_id = a.archer_id
        INNER JOIN classes cls ON a.class_id = cls.class_id
        INNER JOIN equipment e ON s.equipment_id = e.equipment_id
        WHERE c.is_championship = TRUE
        ORDER BY c.date DESC, cr.rank ASC
    ";

    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
      echo '<table border="1" style="border-collapse: collapse; width: 100%; margin: 20px 0;">';
      echo '<thead style="background-color: #f2f2f2;">';
      echo '<tr>';
      echo '<th>Competition</th>';
      echo '<th>Archer</th>';
      echo '<th>Class</th>';
      echo '<th>Equipment</th>';
      echo '<th>Score</th>';
      echo '<th>Rank</th>';
      echo '</tr>';
      echo '</thead>';
      echo '<tbody>';

      while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['competition_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['archer_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['class_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['equipment_name']) . '</td>';
        echo '<td style="text-align: center;">' . htmlspecialchars($row['score']) . '</td>';
        echo '<td style="text-align: center;">';

        // Hiển thị rank với icon đặc biệt cho top 3
        if ($row['rank'] == 1) {
          echo '🥇 ' . $row['rank'];
        } elseif ($row['rank'] == 2) {
          echo '🥈 ' . $row['rank'];
        } elseif ($row['rank'] == 3) {
          echo '🥉 ' . $row['rank'];
        } else {
          echo $row['rank'];
        }

        echo '</td>';
        echo '</tr>';
      }

      echo '</tbody>';
      echo '</table>';
    } else {
      echo '<p>No championship results found.</p>';
    }

    // Đóng kết nối
    if (isset($conn)) {
      $conn->close();
    }
    ?>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>