<?php
include 'connection.php';
session_start();

// Xử lý các hành động
$action = $_POST['action'] ?? '';
$id = $_POST['id'] ?? '';

if ($action === 'save') {
  $round_id = $_POST['round_id'];
  $equivalent_round_id = $_POST['equivalent_round_id'];
  $valid_from = $_POST['valid_from'];
  $valid_to = $_POST['valid_to'] ?: null;

  if ($id) {
    // Update existing record
    $sql = "UPDATE equivalent_rounds SET round_id = ?, equivalent_round_id = ?, valid_from = ?, valid_to = ? WHERE equivalent_round_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iissi", $round_id, $equivalent_round_id, $valid_from, $valid_to, $id);
  } else {
    // Insert new record
    $sql = "INSERT INTO equivalent_rounds (round_id, equivalent_round_id, valid_from, valid_to) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $round_id, $equivalent_round_id, $valid_from, $valid_to);
  }

  if ($stmt->execute()) {
    $_SESSION['message'] = $id ? "Equivalent round updated successfully!" : "Equivalent round added successfully!";
  } else {
    $_SESSION['error'] = "Error saving equivalent round: " . $conn->error;
  }
  $stmt->close();
}

if ($action === 'delete' && $id) {
  $sql = "DELETE FROM equivalent_rounds WHERE equivalent_round_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $id);

  if ($stmt->execute()) {
    $_SESSION['message'] = "Equivalent round deleted successfully!";
  } else {
    $_SESSION['error'] = "Error deleting equivalent round: " . $conn->error;
  }
  $stmt->close();
}

// Lấy dữ liệu để edit
$edit_data = null;
if ($action === 'edit' && $id) {
  $sql = "SELECT * FROM equivalent_rounds WHERE equivalent_round_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $result = $stmt->get_result();
  $edit_data = $result->fetch_assoc();
  $stmt->close();
}

// Lấy danh sách rounds
$rounds_sql = "SELECT round_id, round_name FROM rounds ORDER BY round_name";
$rounds_result = $conn->query($rounds_sql);

// Lấy danh sách equivalent rounds
$sql = "SELECT er.*, r1.round_name as round_name, r2.round_name as equivalent_round_name 
        FROM equivalent_rounds er
        JOIN rounds r1 ON er.round_id = r1.round_id
        JOIN rounds r2 ON er.equivalent_round_id = r2.round_id
        ORDER BY er.valid_from DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Equivalent Rounds Management</title>
  <link rel="stylesheet" href="styles.css">
  <style>
    .message {
      padding: 10px;
      margin: 10px 0;
      border-radius: 4px;
    }

    .success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f8f9fa;
    }

    .actions {
      white-space: nowrap;
    }

    .actions button {
      margin-right: 5px;
    }

    form {
      background: #f8f9fa;
      padding: 20px;
      border-radius: 5px;
      margin: 20px 0;
    }

    .form-group {
      margin-bottom: 15px;
    }

    label {
      display: inline-block;
      width: 150px;
      font-weight: bold;
    }

    input,
    select {
      padding: 8px;
      width: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }

    button {
      padding: 10px 20px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    button:hover {
      background: #0056b3;
    }

    .delete-btn {
      background: #dc3545;
    }

    .delete-btn:hover {
      background: #c82333;
    }
  </style>
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Equivalent Rounds Management</h1>

    <?php if (isset($_SESSION['message'])): ?>
      <div class="message success"><?php echo $_SESSION['message'];
                                    unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
      <div class="message error"><?php echo $_SESSION['error'];
                                  unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="POST">
      <input type="hidden" name="id" value="<?php echo $edit_data['equivalent_round_id'] ?? ''; ?>">

      <div class="form-group">
        <label for="round_id">Round:</label>
        <select id="round_id" name="round_id" required>
          <option value="">Select Round</option>
          <?php while ($round = $rounds_result->fetch_assoc()): ?>
            <option value="<?php echo $round['round_id']; ?>"
              <?php if (isset($edit_data['round_id']) && $edit_data['round_id'] == $round['round_id']) echo 'selected'; ?>>
              <?php echo htmlspecialchars($round['round_name']); ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="equivalent_round_id">Equivalent Round:</label>
        <select id="equivalent_round_id" name="equivalent_round_id" required>
          <option value="">Select Equivalent Round</option>
          <?php
          $rounds_result->data_seek(0); // Reset result pointer
          while ($round = $rounds_result->fetch_assoc()): ?>
            <option value="<?php echo $round['round_id']; ?>"
              <?php if (isset($edit_data['equivalent_round_id']) && $edit_data['equivalent_round_id'] == $round['round_id']) echo 'selected'; ?>>
              <?php echo htmlspecialchars($round['round_name']); ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="form-group">
        <label for="valid_from">Valid From:</label>
        <input type="date" id="valid_from" name="valid_from"
          value="<?php echo $edit_data['valid_from'] ?? ''; ?>" required>
      </div>

      <div class="form-group">
        <label for="valid_to">Valid To:</label>
        <input type="date" id="valid_to" name="valid_to"
          value="<?php echo $edit_data['valid_to'] ?? ''; ?>">
        <small>(Leave empty if currently valid)</small>
      </div>

      <button type="submit" name="action" value="save">
        <?php echo isset($edit_data) ? 'Update' : 'Save'; ?> Equivalent Round
      </button>

      <?php if (isset($edit_data)): ?>
        <button type="button" onclick="window.location.href='equivalent_rounds_management.php'">Cancel</button>
      <?php endif; ?>
    </form>

    <h2>Existing Equivalent Rounds</h2>
    <table>
      <thead>
        <tr>
          <th>Round</th>
          <th>Equivalent Round</th>
          <th>Valid From</th>
          <th>Valid To</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?php echo htmlspecialchars($row['round_name']); ?></td>
            <td><?php echo htmlspecialchars($row['equivalent_round_name']); ?></td>
            <td><?php echo htmlspecialchars($row['valid_from']); ?></td>
            <td><?php echo htmlspecialchars($row['valid_to'] ?? 'Current'); ?></td>
            <td class="actions">
              <form method="POST" style="display: inline;">
                <input type="hidden" name="id" value="<?php echo $row['equivalent_round_id']; ?>">
                <button type="submit" name="action" value="edit">Edit</button>
              </form>
              <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this equivalent round?');">
                <input type="hidden" name="id" value="<?php echo $row['equivalent_round_id']; ?>">
                <button type="submit" name="action" value="delete" class="delete-btn">Delete</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>

<?php $conn->close(); ?>