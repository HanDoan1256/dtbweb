<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archery Management — Practice Score</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <?php
    include 'header.inc';
    include 'connection.php';

    if (!isset($_SESSION['user_id'])) {
        echo "<div class='error-message'>Error: Please log in first.</div>";
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $archer_id = null;

    // Lấy archer_id từ accounts
    $stmt = $conn->prepare("SELECT archer_id FROM accounts WHERE archer_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $archer_id = $row['archer_id'];
    }
    $stmt->close();

    if (!$archer_id) {
        echo "<div class='error-message'>Error: Cannot find archer information for user: $user_id</div>";
        exit;
    }
    ?>

    <main>
        <section id="practice-score" aria-labelledby="eps-title">
            <h1 id="eps-title">Enter Practice Score</h1>

            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $round_id = $_POST['round_id'];
                $equipment_id = $_POST['equipment_id'];
                $date = $_POST['date'];
                $time = $_POST['time'];
                $total_score = $_POST['total_score'];
                $datetime = $date . ' ' . $time . ':00';
                $status = "pending";

                // INSERT vào staging_scores
                $sql = "INSERT INTO staging_scores (archer_id, round_id, datetime, equipment_id, total_score, status) 
                        VALUES (?, ?, ?, ?, ?, ?)";

                $stmt = $conn->prepare($sql);

                if ($stmt) {
                    $stmt->bind_param("iissis", $archer_id, $round_id, $datetime, $equipment_id, $total_score, $status);

                    if ($stmt->execute()) {
                        echo "<div class='success-message'>✅ Practice score submitted successfully!</div>";
                    } else {
                        echo "<div class='error-message'>❌ Error: " . $stmt->error . "</div>";
                    }
                    $stmt->close();
                } else {
                    echo "<div class='error-message'>❌ Database error: " . $conn->error . "</div>";
                }
            }
            ?>

            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <ol>
                    <li>
                        <strong>Step 1: Select Round</strong>
                        <div>
                            <label for="eps-round">Round:</label>
                            <select id="eps-round" name="round_id" required>
                                <option value="">Select a round</option>
                                <?php
                                $rounds_result = $conn->query("SELECT round_id, name FROM rounds ORDER BY name");
                                while ($round = $rounds_result->fetch_assoc()) {
                                    echo "<option value='{$round['round_id']}'>{$round['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </li>

                    <li>
                        <strong>Step 2: Select Equipment</strong>
                        <div>
                            <label for="eps-equip">Equipment:</label>
                            <select id="eps-equip" name="equipment_id" required>
                                <option value="">Select equipment</option>
                                <?php
                                $equip_result = $conn->query("SELECT equipment_id, name FROM equipment ORDER BY name");
                                while ($equip = $equip_result->fetch_assoc()) {
                                    echo "<option value='{$equip['equipment_id']}'>{$equip['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </li>

                    <li>
                        <strong>Step 3: Set Date & Time</strong>
                        <div>
                            <label for="eps-date">Date:</label>
                            <input type="date" id="eps-date" name="date" value="<?php echo date('Y-m-d'); ?>" required />
                            <label for="eps-time">Time:</label>
                            <input type="time" id="eps-time" name="time" value="<?php echo date('H:i'); ?>" required />
                        </div>
                    </li>

                    <li>
                        <strong>Step 4: Enter Scores</strong>
                        <p>Enter score for each end (max 60 per end):</p>

                        <table id="endsTable">
                            <thead>
                                <tr>
                                    <th>End</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody id="endsBody"></tbody>
                        </table>

                        <p class="button-group">
                            <button type="button" id="addEndBtn">+ Add End</button>
                            <button type="button" id="clearBtn">Clear All</button>
                        </p>

                        <p>Total Score: <strong id="grandTotal">0</strong></p>
                        <input type="hidden" id="total_score" name="total_score" value="0">
                    </li>

                    <li>
                        <strong>Step 5: Submit</strong>
                        <p>Archer ID: <strong><?php echo $archer_id; ?></strong></p>
                        <button type="submit">Submit Practice Score</button>
                    </li>
                </ol>
            </form>
        </section>
    </main>

    <?php include 'footer.inc'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const endsBody = document.getElementById('endsBody');
            const addEndBtn = document.getElementById('addEndBtn');
            const clearBtn = document.getElementById('clearBtn');
            const grandTotalElem = document.getElementById('grandTotal');
            const totalScoreInput = document.getElementById('total_score');
            let endCount = 0;

            function addEnd() {
                endCount++;
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${endCount}</td>
                    <td><input type="number" class="end-score" min="0" max="60" value="0"></td>
                `;
                endsBody.appendChild(row);
                row.querySelector('.end-score').addEventListener('input', updateTotal);
                updateTotal();
            }

            function updateTotal() {
                let total = 0;
                document.querySelectorAll('.end-score').forEach(input => {
                    total += parseInt(input.value) || 0;
                });
                grandTotalElem.textContent = total;
                totalScoreInput.value = total;
            }

            addEndBtn.addEventListener('click', addEnd);

            clearBtn.addEventListener('click', function() {
                if (confirm('Clear all scores?')) {
                    endsBody.innerHTML = '';
                    endCount = 0;
                    updateTotal();
                }
            });

            // Thêm 6 ends mặc định
            for (let i = 0; i < 6; i++) addEnd();
        });
    </script>
</body>

</html>