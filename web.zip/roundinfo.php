<?php
require_once 'connection.php';

// Lấy danh sách rounds từ database
$rounds_result = $conn->query("SELECT * FROM rounds ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Archery Management — Round Info</title>
  <link rel="stylesheet" href="styles.css?v=1" />
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <section id="round-info" aria-labelledby="round-title">
      <h1 id="round-title">Round Info Lookup</h1>

      <h2>Select Round → Show:</h2>
      <form method="GET" action="">
        <label for="ri-round">Round:</label>
        <select id="ri-round" name="round_id">
          <option value="">Select a Round</option>
          <?php while ($round = $rounds_result->fetch_assoc()): ?>
            <option value="<?php echo $round['round_id']; ?>"
              <?php if (isset($_GET['round_id']) && $_GET['round_id'] == $round['round_id']) echo 'selected'; ?>>
              <?php echo htmlspecialchars($round['name']); ?>
            </option>
          <?php endwhile; ?>
        </select>
        <button type="submit">Show Info</button>
      </form>

      <?php
      // Hiển thị thông tin round khi được chọn
      if (isset($_GET['round_id']) && !empty($_GET['round_id'])) {
        $round_id = $_GET['round_id'];

        // Lấy thông tin round
        $round_query = "SELECT * FROM rounds WHERE round_id = ?";
        $round_stmt = $conn->prepare($round_query);
        $round_stmt->bind_param("i", $round_id);
        $round_stmt->execute();
        $round_result = $round_stmt->get_result();
        $round = $round_result->fetch_assoc();

        // Lấy thông tin ranges
        $ranges_query = "SELECT * FROM ranges WHERE round_id = ? ORDER BY range_number";
        $ranges_stmt = $conn->prepare($ranges_query);
        $ranges_stmt->bind_param("i", $round_id);
        $ranges_stmt->execute();
        $ranges_result = $ranges_stmt->get_result();

        if ($round) {
          echo '<div style="background: #181a1cff; padding: 20px; margin: 20px 0; border-radius: 8px;">';
          echo '<h3>Round Details: ' . htmlspecialchars($round['name']) . '</h3>';
          echo '<p><strong>Total Arrows:</strong> ' . $round['total_arrows'] . '</p>';
          echo '<p><strong>Possible Score:</strong> ' . $round['possible_score'] . '</p>';

          if ($ranges_result->num_rows > 0) {
            echo '<h4>Ranges:</h4>';
            echo '<table border="1" style="border-collapse: collapse; width: 100%;">';
            echo '<tr style="background-color: #181a1cff;">';
            echo '<th>Range #</th><th>Distance</th><th>Target Face</th><th>Number of Ends</th><th>Arrows</th>';
            echo '</tr>';

            $total_ends = 0;
            while ($range = $ranges_result->fetch_assoc()) {
              $arrows_in_range = $range['num_ends'] * 6;
              echo '<tr>';
              echo '<td style="text-align: center;">' . $range['range_number'] . '</td>';
              echo '<td style="text-align: center;">' . $range['distance'] . 'm</td>';
              echo '<td style="text-align: center;">' . htmlspecialchars($range['target_face']) . '</td>';
              echo '<td style="text-align: center;">' . $range['num_ends'] . '</td>';
              echo '<td style="text-align: center;">' . $arrows_in_range . '</td>';
              echo '</tr>';
              $total_ends += $range['num_ends'];
            }

            echo '<tr style="background-color: #181a1cff; font-weight: bold;">';
            echo '<td colspan="3" style="text-align: right;">Total:</td>';
            echo '<td style="text-align: center;">' . $total_ends . '</td>';
            echo '<td style="text-align: center;">' . $round['total_arrows'] . '</td>';
            echo '</tr>';
            echo '</table>';
          }

          echo '</div>';

          // Hiển thị equivalent rounds
          echo '<div style="background: #181a1cff; padding: 20px; margin: 20px 0; border-radius: 8px;">';
          echo '<h3>Equivalent Rounds</h3>';

          $equiv_query = "
              SELECT er.equivalent_round_id, r.name, c.name as class_name, e.name as equipment_name
              FROM equivalent_rounds er
              JOIN rounds r ON er.equivalent_round_id = r.round_id
              JOIN classes c ON er.class_id = c.class_id
              JOIN equipment e ON er.equipment_id = e.equipment_id
              WHERE er.base_round_id = ?
              ORDER BY c.name, e.name
          ";
          $equiv_stmt = $conn->prepare($equiv_query);
          $equiv_stmt->bind_param("i", $round_id);
          $equiv_stmt->execute();
          $equiv_result = $equiv_stmt->get_result();

          if ($equiv_result->num_rows > 0) {
            echo '<table border="1" style="border-collapse: collapse; width: 100%;">';
            echo '<tr style="background-color: #181a1cff;">';
            echo '<th>Class</th><th>Equipment</th><th>Equivalent Round</th>';
            echo '</tr>';

            while ($equiv = $equiv_result->fetch_assoc()) {
              echo '<tr>';
              echo '<td>' . htmlspecialchars($equiv['class_name']) . '</td>';
              echo '<td>' . htmlspecialchars($equiv['equipment_name']) . '</td>';
              echo '<td>' . htmlspecialchars($equiv['name']) . '</td>';
              echo '</tr>';
            }
            echo '</table>';
          } else {
            echo '<p>No equivalent rounds found for this round.</p>';
          }
          echo '</div>';

          $round_stmt->close();
          $ranges_stmt->close();
          $equiv_stmt->close();
        } else {
          echo '<p style="color: red;">Round not found.</p>';
        }
      }

      $conn->close();
      ?>
    </section>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>