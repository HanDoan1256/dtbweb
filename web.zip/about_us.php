<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meet the Team</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <?php include 'header.inc'; ?>
    <main>



        <h2 class="abth2"> <span class="abt2light">COS20031-Database Design Project</span></h2>
        <h3> GROUP: OMOMATIC (WED.02) </h3>
        <h3> TUTOR: Wilson Doan </h3>

        <section class="team-container">

            <div class="team-member">
                <img src="khangnguyen.jpg" height="200" width="150" alt="Nguyen Huu Thien Khang">
                <div id="TK" class="team-info">
                    <h3>Nguyen Huu Thien Khang</h3>
                    <p>Student ID: 105507230</p>
                    <p>Email: <a href="#">khang@gmail.com</a></p>
                    <p>Major: Data Science</p>
                </div>
            </div>

            <div class="team-member">
                <img src="handoan.jpg" height="200" width="150" alt="Doan Gia Han">
                <div id="GH" class="team-info">
                    <h3>Doan Gia Han</h3>
                    <p>Student ID: 105506817</p>
                    <p>Email: <a href="mailto:handoangia2612@gmail.com">handoangia2612@gmail.com</a></p>
                    <p>Major: Data Science</p>
                </div>
            </div>

            <div class="team-member">
                <img src="nhu.jpg" height="200" width="150" alt="Ngo Quynh Nhu">
                <div id="QN" class="team-info">
                    <h3>Ngo Quynh Nhu</h3>
                    <p>Student ID: 105312140</p>
                    <p>Email: <a href="mailto:quynhnhungo06@gmail.com">quynhnhungo06@gmail.com</a></p>
                    <p>Major: Artificial Intelligence</p>
                </div>
            </div>

            <div class="team-member">
                <img src="duydo.jpg" height="200" width="150" alt="Do Duc Duy">
                <div id="DD" class="team-info">
                    <h3>Do Duc Duy</h3>
                    <p>Student ID: 105550034</p>
                    <p>Email: <a href="#">duy@gmail.com</a></p>
                    <p>Major: Artificial Intelligence</p>
                </div>

            </div>
            <div class="team-member">
                <img src="tinnguyen.jpg" height="200" width="150" alt="Nguyen Trong Tin">
                <div id="NT" class="team-info">
                    <h3>Nguyen Trong Tin</h3>
                    <p>Student ID: 105507233</p>
                    <p>Email: <a href="#">tin@gmail.com</a></p>
                    <p>Major: Artificial Intelligence</p>
                </div>
            </div>
        </section>


        <br>
        <br>
        <br>
        <br>
        <hr />
    </main>
    <?php include 'footer.inc'; ?>
</body>

</html>