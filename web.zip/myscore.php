<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Archery Management — My Scores</title>
  <link rel="stylesheet" href="styles.css" />
</head>

<body>
  <?php
  include 'header.inc';
  include 'connection.php';

  // Lấy archer_id từ session
  $user_id = $_SESSION['user_id'] ?? '';
  $archer_id = null;

  if ($user_id) {
    $stmt = $conn->prepare("SELECT archer_id FROM accounts WHERE archer_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
      $archer_id = $row['archer_id'];
    }
    $stmt->close();
  }

  // Xử lý filter
  $filter_round = $_GET['round'] ?? '';
  $filter_from = $_GET['from_date'] ?? '';
  $filter_to = $_GET['to_date'] ?? '';
  $filter_status = $_GET['status'] ?? '';

  // Build query
  $query = "SELECT 
            ps.practice_scoreID,
            ps.datetime,
            r.name as round_name,
            e.name as equipment_name,
            ps.total_score,
            ps.notes,
            'approved' as status
          FROM practice_score ps
          JOIN rounds r ON ps.round_id = r.round_id
          JOIN equipment e ON ps.equipment_id = e.equipment_id
          WHERE ps.archer_id = ?";

  $params = [$archer_id];
  $types = "i";

  if ($filter_round && $filter_round !== 'any') {
    $query .= " AND r.name LIKE ?";
    $params[] = "%$filter_round%";
    $types .= "s";
  }

  if ($filter_from) {
    $query .= " AND DATE(ps.datetime) >= ?";
    $params[] = $filter_from;
    $types .= "s";
  }

  if ($filter_to) {
    $query .= " AND DATE(ps.datetime) <= ?";
    $params[] = $filter_to;
    $types .= "s";
  }

  $query .= " ORDER BY ps.datetime DESC";

  // Execute query
  $scores = [];
  if ($archer_id) {
    $stmt = $conn->prepare($query);
    if ($stmt) {
      $stmt->bind_param($types, ...$params);
      $stmt->execute();
      $result = $stmt->get_result();

      while ($row = $result->fetch_assoc()) {
        $scores[] = $row;
      }
      $stmt->close();
    }
  }

  // Lấy danh sách rounds cho dropdown
  $rounds_result = $conn->query("SELECT DISTINCT name FROM rounds ORDER BY name");
  $rounds = [];
  while ($round = $rounds_result->fetch_assoc()) {
    $rounds[] = $round['name'];
  }
  ?>

  <main>
    <section id="my-scores" aria-labelledby="scores-title">
      <h1 id="scores-title">My Scores</h1>

      <h2>Filter</h2>
      <form method="GET" action="">
        <label for="filter-round">Round:</label>
        <select id="filter-round" name="round">
          <option value="any">Any</option>
          <?php foreach ($rounds as $round): ?>
            <option value="<?php echo htmlspecialchars($round); ?>"
              <?php echo $filter_round === $round ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars($round); ?>
            </option>
          <?php endforeach; ?>
        </select>

        <label for="from-date">From:</label>
        <input type="date" id="from-date" name="from_date" value="<?php echo htmlspecialchars($filter_from); ?>" />

        <label for="to-date">To:</label>
        <input type="date" id="to-date" name="to_date" value="<?php echo htmlspecialchars($filter_to); ?>" />

        <label for="filter-status">Status:</label>
        <select id="filter-status" name="status">
          <option value="">All</option>
          <option value="approved" <?php echo $filter_status === 'approved' ? 'selected' : ''; ?>>Approved</option>
          <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
        </select>

        <button type="submit">Apply Filters</button>
        <button type="button" onclick="window.location.href='myscore.php'">Clear Filters</button>
      </form>

      <h2>Sort</h2>
      <form id="sort-form">
        <label><input type="radio" name="sort" value="date" checked /> By Date (Newest First)</label>
        <label><input type="radio" name="sort" value="score" /> By Total Score (Highest First)</label>
      </form>

      <h2>Score Statistics</h2>
      <div class="stats">
        <?php
        $total_scores = count($scores);
        $avg_score = $total_scores > 0 ? array_sum(array_column($scores, 'total_score')) / $total_scores : 0;
        $max_score = $total_scores > 0 ? max(array_column($scores, 'total_score')) : 0;
        ?>
        <p>Total Scores: <strong><?php echo $total_scores; ?></strong></p>
        <p>Average Score: <strong><?php echo round($avg_score, 1); ?></strong></p>
        <p>Best Score: <strong><?php echo $max_score; ?></strong></p>
      </div>

      <h2>My Scores (<?php echo count($scores); ?>)</h2>

      <?php if (empty($scores)): ?>
        <div class="no-scores">
          <p>No scores found. <a href="practicescore.php">Submit your first score!</a></p>
        </div>
      <?php else: ?>
        <table class="scores-table">
          <thead>
            <tr>
              <th>Date & Time</th>
              <th>Round</th>
              <th>Equipment</th>
              <th>Total Score</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($scores as $score): ?>
              <tr>
                <td><?php echo date('Y-m-d H:i', strtotime($score['datetime'])); ?></td>
                <td><?php echo htmlspecialchars($score['round_name']); ?></td>
                <td><?php echo htmlspecialchars($score['equipment_name']); ?></td>
                <td class="score-value"><?php echo $score['total_score']; ?></td>
                <td class="status-<?php echo $score['status']; ?>">
                  <?php echo ucfirst($score['status']); ?>
                </td>
                <td class="notes"><?php echo htmlspecialchars($score['notes'] ?? ''); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </section>
  </main>

  <?php include 'footer.inc'; ?>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Sort functionality
      const sortRadios = document.querySelectorAll('input[name="sort"]');
      const tableBody = document.querySelector('.scores-table tbody');

      sortRadios.forEach(radio => {
        radio.addEventListener('change', function() {
          if (tableBody) {
            sortTable(this.value);
          }
        });
      });

      function sortTable(sortBy) {
        const rows = Array.from(tableBody.querySelectorAll('tr'));

        rows.sort((a, b) => {
          if (sortBy === 'date') {
            const dateA = new Date(a.cells[0].textContent);
            const dateB = new Date(b.cells[0].textContent);
            return dateB - dateA; // Newest first
          } else {
            const scoreA = parseInt(a.cells[3].textContent);
            const scoreB = parseInt(b.cells[3].textContent);
            return scoreB - scoreA; // Highest first
          }
        });

        // Clear and re-append sorted rows
        tableBody.innerHTML = '';
        rows.forEach(row => tableBody.appendChild(row));
      }

      // Auto-submit sort form when radio changes
      document.getElementById('sort-form').addEventListener('change', function() {
        const formData = new FormData(this);
        const sortValue = formData.get('sort');
        // In a real app, you might want to submit this to server
        // For now, we'll just sort client-side
      });
    });
  </script>
</body>

</html>