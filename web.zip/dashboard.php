<?php
require_once 'manage_access.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Archer Dashboard</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main class="dashboard-container">
    <h1>Archer Dashboard</h1>
    <div class="welcome-message">
      <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_id']); ?></strong>!</p>
      <p>Role: <span class="role-badge archer">Archer</span></p>
    </div>

    <div class="dashboard-grid">
      <div class="dashboard-card">
        <h3>Record Scores</h3>
        <p>Record your practice and competition scores</p>
        <a href="practicescore.php" class="btn btn-primary">Record Practice Score</a>
      </div>

      <div class="dashboard-card">
        <h3>My Scores</h3>
        <p>View your historical scores and progress</p>
        <a href="myscore.php" class="btn btn-primary">View My Scores</a>
      </div>

      <div class="dashboard-card">
        <h3>Personal Bests</h3>
        <p>Check your personal best achievements</p>
        <a href="personalbest.php" class="btn btn-primary">View Personal Bests</a>
      </div>

      <div class="dashboard-card">
        <h3>Round Information</h3>
        <p>Learn about different archery rounds</p>
        <a href="roundinfo.php" class="btn btn-primary">Round Info</a>
      </div>

      <div class="dashboard-card">
        <h3>Competition Results</h3>
        <p>View competition results and rankings</p>
        <a href="compresult.php" class="btn btn-primary">Competition Results</a>
      </div>

      <div class="dashboard-card">
        <h3>My Profile</h3>
        <p>Manage your personal information</p>
        <a href="profile.php?id=<?php echo $_SESSION['user_id']; ?>" class="btn btn-secondary">Edit Profile</a>
      </div>
    </div>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>