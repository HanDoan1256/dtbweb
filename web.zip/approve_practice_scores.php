<?php
include 'header.inc';
include 'connection.php';

// Xử lý approve/reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $staging_id = $_POST['staging_id'] ?? '';
  $action = $_POST['action'] ?? '';

  if ($staging_id && in_array($action, ['approve', 'reject'])) {
    // Lấy thông tin từ staging_scores
    $stmt = $conn->prepare("SELECT * FROM staging_scores WHERE staging_id = ?");
    $stmt->bind_param("i", $staging_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($score_data = $result->fetch_assoc()) {
      if ($action === 'approve') {
        // Kiểm tra xem ngày có trùng với competition không
        $score_date = date('Y-m-d', strtotime($score_data['datetime']));

        $check_comp_stmt = $conn->prepare("SELECT comp_id FROM competitions WHERE date = ?");
        $check_comp_stmt->bind_param("s", $score_date);
        $check_comp_stmt->execute();
        $comp_result = $check_comp_stmt->get_result();

        $notes = "Approved on " . date('Y-m-d H:i:s');

        if ($comp_result->num_rows > 0) {
          // Có competition trong ngày này - insert vào bảng scores
          $insert_stmt = $conn->prepare("INSERT INTO scores (archer_id, round_id, datetime, equipment_id, total_score, notes) VALUES (?, ?, ?, ?, ?, ?)");
          $insert_stmt->bind_param(
            "iissis",
            $score_data['archer_id'],
            $score_data['round_id'],
            $score_data['datetime'],
            $score_data['equipment_id'],
            $score_data['total_score'],
            $notes
          );

          if ($insert_stmt->execute()) {
            // Cập nhật status staging_scores thành approved
            $update_stmt = $conn->prepare("UPDATE staging_scores SET status = 'approved' WHERE staging_id = ?");
            $update_stmt->bind_param("i", $staging_id);
            $update_stmt->execute();
            $message = "Score approved successfully and added to competition scores!";
          }
          $insert_stmt->close();
        } else {
          // Không có competition - insert vào bảng practice_score
          $insert_stmt = $conn->prepare("INSERT INTO practice_score (archer_id, round_id, datetime, equipment_id, total_score, notes) VALUES (?, ?, ?, ?, ?, ?)");
          $insert_stmt->bind_param(
            "iissis",
            $score_data['archer_id'],
            $score_data['round_id'],
            $score_data['datetime'],
            $score_data['equipment_id'],
            $score_data['total_score'],
            $notes
          );

          if ($insert_stmt->execute()) {
            // Cập nhật status staging_scores thành approved
            $update_stmt = $conn->prepare("UPDATE staging_scores SET status = 'approved' WHERE staging_id = ?");
            $update_stmt->bind_param("i", $staging_id);
            $update_stmt->execute();
            $message = "Score approved successfully and added to practice scores!";
          }
          $insert_stmt->close();
        }
        $check_comp_stmt->close();
      } elseif ($action === 'reject') {
        // Cập nhật status staging_scores thành rejected
        $update_stmt = $conn->prepare("UPDATE staging_scores SET status = 'rejected' WHERE staging_id = ?");
        $update_stmt->bind_param("i", $staging_id);
        $update_stmt->execute();
        $message = "Score rejected successfully!";
      }
    }
    $stmt->close();
  }
}

// Lấy danh sách pending scores từ staging_scores
$query = "SELECT 
            ss.staging_id,
            ss.archer_id,
            a.name as archer_name,
            r.name as round_name,
            e.name as equipment_name,
            ss.datetime,
            ss.total_score,
            ss.status
          FROM staging_scores ss
          JOIN archers a ON ss.archer_id = a.archer_id
          JOIN rounds r ON ss.round_id = r.round_id
          JOIN equipment e ON ss.equipment_id = e.equipment_id
          WHERE ss.status = 'pending'
          ORDER BY ss.datetime DESC";

$result = $conn->query($query);
$pending_scores = [];
while ($row = $result->fetch_assoc()) {
  $pending_scores[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Approve Practice Scores</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Approve Practice Scores</h1>

    <?php if (isset($message)): ?>
      <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if (empty($pending_scores)): ?>
      <p>No pending scores to approve.</p>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th>Archer</th>
            <th>Round</th>
            <th>Equipment</th>
            <th>Date & Time</th>
            <th>Score</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pending_scores as $score): ?>
            <tr>
              <td><?php echo htmlspecialchars($score['archer_name']); ?> (ID: <?php echo $score['archer_id']; ?>)</td>
              <td><?php echo htmlspecialchars($score['round_name']); ?></td>
              <td><?php echo htmlspecialchars($score['equipment_name']); ?></td>
              <td><?php echo date('Y-m-d H:i', strtotime($score['datetime'])); ?></td>
              <td><strong><?php echo $score['total_score']; ?></strong></td>
              <td>
                <form method="POST" style="display: inline;">
                  <input type="hidden" name="staging_id" value="<?php echo $score['staging_id']; ?>">
                  <input type="hidden" name="action" value="approve">
                  <button type="submit" class="approve-btn">Approve</button>
                </form>
                <form method="POST" style="display: inline;">
                  <input type="hidden" name="staging_id" value="<?php echo $score['staging_id']; ?>">
                  <input type="hidden" name="action" value="reject">
                  <button type="submit" class="reject-btn">Reject</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>