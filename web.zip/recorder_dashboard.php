<?php
require_once 'manage_access.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recorder Dashboard</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main class="dashboard-container">
    <h1>Recorder Dashboard</h1>
    <div class="welcome-message">
      <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_id']); ?></strong>!</p>
      <p>Role: <span class="role-badge recorder">Recorder</span></p>
    </div>

    <div class="dashboard-grid">
      <div class="dashboard-card">
        <h3>Approve Scores</h3>
        <p>Review and approve archer practice scores</p>
        <a href="approve_practice_scores.php" class="btn btn-primary">Approve Scores</a>
      </div>

      <div class="dashboard-card">
        <h3>Competition Management</h3>
        <p>Manage competitions and events</p>
        <a href="competition_management.php" class="btn btn-primary">Manage Competitions</a>
      </div>

      <div class="dashboard-card">
        <h3>Championship Management</h3>
        <p>Organize championship events</p>
        <a href="championship_management.php" class="btn btn-primary">Manage Championships</a>
      </div>

      <div class="dashboard-card">
        <h3>Archer Round Management</h3>
        <p>Configure archer rounds and formats</p>
        <a href="archer_round_management.php" class="btn btn-primary">Manage Rounds</a>
      </div>

      <div class="dashboard-card">
        <h3>Equivalent Rounds</h3>
        <p>Manage equivalent round calculations</p>
        <a href="equivalent_rounds_management.php" class="btn btn-primary">Equivalent Rounds</a>
      </div>

      <div class="dashboard-card">
        <h3>Equipment Classes</h3>
        <p>Manage archery equipment classifications</p>
        <a href="equipment_class_management.php" class="btn btn-primary">Equipment Classes</a>
      </div>

      <div class="dashboard-card">
        <h3>My Profile</h3>
        <p>Manage your recorder account</p>
        <a href="profile.php?id=<?php echo $_SESSION['user_id']; ?>" class="btn btn-secondary">Edit Profile</a>
      </div>
    </div>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>