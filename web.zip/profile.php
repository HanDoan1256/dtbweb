<?php
require_once 'connection.php';
require_once 'manage_access.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

// Get the logged-in user's ID and role from session
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'];

// Fetch profile data based on role
$profile = null;
$isRecorder = ($userRole === ROLE_RECORDER);

if ($conn && !$conn->connect_error) {
    if ($isRecorder) {
        // Fetch recorder profile from accounts table
        $query = "
            SELECT 
                username,
                archer_id,
                user_role
            FROM accounts 
            WHERE username = ? OR archer_id = ?
        ";

        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $userId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $profile = $result->fetch_assoc();
        $stmt->close();
    } else {
        // Fetch archer profile with joins
        $query = "
            SELECT 
                a.archer_id,
                a.name,
                a.dob,
                a.gender,
                e.name as equipment_name,
                c.name as class_name,
                acc.username,
                acc.user_role
            FROM accounts acc
            INNER JOIN archers a ON acc.archer_id = a.archer_id
            LEFT JOIN equipment e ON a.default_equipment_id = e.equipment_id
            LEFT JOIN classes c ON a.class_id = c.class_id
            WHERE acc.username = ? OR acc.archer_id = ?
        ";

        $stmt = $conn->prepare($query);

        // Bind parameters based on whether user_id is archer_id or username
        if (is_numeric($userId)) {
            $stmt->bind_param("ii", $userId, $userId);
        } else {
            $stmt->bind_param("ss", $userId, $userId);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $profile = $result->fetch_assoc();
        $stmt->close();
    }
}

function formatDate($date)
{
    if (!$date || $date == '0000-00-00') return '—';
    return date('M j, Y', strtotime($date));
}

function e($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// Function to check if table exists
function tableExists($conn, $tableName)
{
    $result = $conn->query("SHOW TABLES LIKE '$tableName'");
    return $result->num_rows > 0;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archery Management — Profile</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
    <?php include 'header.inc'; ?>

    <main>
        <section id="profile" class="profile-section">
            <div class="profile-header">
                <h1>My Profile</h1>
                <div class="profile-actions">
                    <a href="<?php echo user_dashboard_for_role($userRole); ?>" class="btn">Back to Dashboard</a>
                </div>
            </div>

            <?php if ($profile): ?>
                <div class="profile-info">
                    <!-- Common information for both roles -->
                    <div class="profile-field">
                        <strong>User ID:</strong> <span><?= e($userId) ?></span>
                    </div>
                    <div class="profile-field">
                        <strong>Role:</strong> <span class="role-badge <?= $userRole ?>"><?= ucfirst($userRole) ?></span>
                    </div>

                    <?php if ($isRecorder): ?>
                        <!-- Recorder specific information -->
                        <div class="profile-field">
                            <strong>Username:</strong> <span><?= e($profile['username']) ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Account Type:</strong> <span>Recorder</span>
                        </div>

                        <!-- Recorder Statistics Section -->
                        <div class="profile-stats">
                            <h3>Recorder Statistics</h3>
                            <?php
                            // Initialize stats with zeros
                            $stats = [
                                'pending_scores' => 0,
                                'approved_scores' => 0,
                                'rejected_scores' => 0,
                                'total_archers' => 0
                            ];

                            // Count pending staging scores
                            if (tableExists($conn, 'staging_scores')) {
                                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM staging_scores WHERE status = 'pending'");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $stats['pending_scores'] = $result->fetch_assoc()['count'] ?? 0;
                                $stmt->close();

                                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM staging_scores WHERE status = 'approved'");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $stats['approved_scores'] = $result->fetch_assoc()['count'] ?? 0;
                                $stmt->close();

                                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM staging_scores WHERE status = 'rejected'");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $stats['rejected_scores'] = $result->fetch_assoc()['count'] ?? 0;
                                $stmt->close();
                            }

                            // Count total archers
                            if (tableExists($conn, 'archers')) {
                                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM archers");
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $stats['total_archers'] = $result->fetch_assoc()['count'] ?? 0;
                                $stmt->close();
                            }
                            ?>

                            <div class="stats-grid">
                                <div class="stat-card">
                                    <h4>Scores Pending Approval</h4>
                                    <div class="stat-number"><?= $stats['pending_scores'] ?></div>
                                    <?php if (tableExists($conn, 'staging_scores')): ?>
                                        <a href="approve_practice_scores.php" class="stat-link">Review Scores</a>
                                    <?php endif; ?>
                                </div>
                                <div class="stat-card">
                                    <h4>Approved Scores</h4>
                                    <div class="stat-number"><?= $stats['approved_scores'] ?></div>
                                </div>
                                <div class="stat-card">
                                    <h4>Rejected Scores</h4>
                                    <div class="stat-number"><?= $stats['rejected_scores'] ?></div>
                                </div>
                                <div class="stat-card">
                                    <h4>Registered Archers</h4>
                                    <div class="stat-number"><?= $stats['total_archers'] ?></div>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Actions for Recorder -->
                        <div class="quick-actions">
                            <h3>Quick Actions</h3>
                            <div class="action-buttons">
                                <?php if (tableExists($conn, 'staging_scores')): ?>
                                    <a href="approve_practice_scores.php" class="btn btn-primary">Approve Scores</a>
                                <?php endif; ?>
                                <?php if (tableExists($conn, 'competitions')): ?>
                                    <a href="competition_management.php" class="btn btn-primary">Manage Competitions</a>
                                <?php endif; ?>
                                <?php if (tableExists($conn, 'rounds')): ?>
                                    <a href="archer_round_management.php" class="btn btn-secondary">Manage Rounds</a>
                                <?php endif; ?>
                                <?php if (tableExists($conn, 'equipment')): ?>
                                    <a href="equipment_class_management.php" class="btn btn-secondary">Equipment Classes</a>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php else: ?>
                        <!-- Archer specific information -->
                        <div class="profile-field">
                            <strong>Archer ID:</strong> <span><?= e($profile['archer_id']) ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Name:</strong> <span><?= e($profile['name']) ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Date of Birth:</strong> <span><?= e(formatDate($profile['dob'])) ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Gender:</strong> <span><?= e($profile['gender']) ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Default Equipment:</strong> <span><?= e($profile['equipment_name'] ?? 'Not set') ?></span>
                        </div>
                        <div class="profile-field">
                            <strong>Class:</strong> <span><?= e($profile['class_name'] ?? 'Not set') ?></span>
                        </div>

                        <a href="logout.php" class="logout-btn">Log Out</a>
                        <!-- Archer Statistics -->
                        <?php
                        $archer_stats = [
                            'practice_sessions' => 0,
                            'average_score' => 0,
                            'personal_best' => 0
                        ];

                        if (is_numeric($userId) && tableExists($conn, 'practice_score')) {
                            // Count practice sessions for this archer
                            $stmt = $conn->prepare("SELECT COUNT(*) as count, AVG(total_score) as avg_score, MAX(total_score) as max_score FROM practice_score WHERE archer_id = ?");
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            if ($row = $result->fetch_assoc()) {
                                $archer_stats['practice_sessions'] = $row['count'] ?? 0;
                                $archer_stats['average_score'] = round($row['avg_score'] ?? 0);
                                $archer_stats['personal_best'] = $row['max_score'] ?? 0;
                            }
                            $stmt->close();
                        }
                        ?>

                        <div class="profile-stats">
                            <h3>Archer Statistics</h3>
                            <div class="stats-grid">
                                <div class="stat-card">
                                    <h4>Practice Sessions</h4>
                                    <div class="stat-number"><?= $archer_stats['practice_sessions'] ?></div>
                                </div>
                                <div class="stat-card">
                                    <h4>Average Score</h4>
                                    <div class="stat-number"><?= $archer_stats['average_score'] ?></div>
                                </div>
                                <div class="stat-card">
                                    <h4>Personal Best</h4>
                                    <div class="stat-number"><?= $archer_stats['personal_best'] ?></div>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="profile-error">
                    <p>Profile information not available.</p>
                    <?php if (!$conn || $conn->connect_error): ?>
                        <p><em>Database connection issue - please try again later.</em></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include 'footer.inc'; ?>
</body>

</html>