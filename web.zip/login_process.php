<?php
require_once 'connection.php';
require_once 'manage_access.php';

// DEBUG: Log bắt đầu login process
error_log("=== LOGIN PROCESS STARTED ===");
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);
error_log("Username: " . ($_POST['username'] ?? 'empty'));
error_log("Password length: " . strlen($_POST['password'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Not POST request, redirecting to login");
    header('Location: login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$redirect = trim($_POST['redirect'] ?? $_GET['redirect'] ?? '');
$error = '';

error_log("Processing login for: " . $username);

if ($username === '' || $password === '') {
    $error = 'Please enter both username and password.';
    error_log("Empty username or password");
} else {
    $stmt = $conn->prepare('SELECT username, pass_word, user_role, archer_id FROM accounts WHERE username = ?');
    if ($stmt === false) {
        $error = 'Server error (DB prepare failed).';
        error_log("DB prepare failed");
    } else {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            error_log("User found: " . $username);
            error_log("Stored password: " . $row['pass_word']);
            error_log("User role: " . $row['user_role']);

            $stored = $row['pass_word'];
            $ok = false;

            // DEBUG password verification
            if (password_verify($password, $stored)) {
                $ok = true;
                error_log("Password verified via password_verify");
            } elseif (hash_equals($stored, $password)) {
                $ok = true;
                error_log("Password verified via hash_equals");
            } elseif ($stored === $password) {
                $ok = true;
                error_log("Password verified via plain text");
            } else {
                error_log("Password verification FAILED");
                error_log("Input: '$password'");
                error_log("Stored: '$stored'");
            }

            if ($ok) {
                $userId = $row['archer_id'] ?? $row['username'];
                error_log("Login SUCCESS - User ID: " . $userId . ", Role: " . $row['user_role']);

                login_user($userId, $row['user_role']);

                // DEBUG session after login
                error_log("Session after login - User ID: " . ($_SESSION['user_id'] ?? 'not set'));
                error_log("Session after login - Role: " . ($_SESSION['role'] ?? 'not set'));

                $dashboard = user_dashboard_for_role($row['user_role']);
                error_log("Redirecting to: " . $dashboard);

                header('Location: ' . $dashboard);
                exit;
            } else {
                $error = 'Invalid password.';
                error_log("Setting error: Invalid password");
            }
        } else {
            $error = 'Username not found.';
            error_log("User not found: " . $username);
        }
    }
}

error_log("Login FAILED - Error: " . $error);

// On errors, send back to login page with message and preserve redirect
$params = ['error' => $error];
if ($redirect) $params['redirect'] = $redirect;
header('Location: login.php?' . http_build_query($params));
exit;
