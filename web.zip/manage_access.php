<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const ROLE_ARCHER = 'archer';
const ROLE_RECORDER = 'recorder';

$ACCESS_RULES = [
    ROLE_RECORDER => [
        'recorder_dashboard.php',
        'approve_practice_scores.php',
        'competition_management.php',
        'championship_management.php',
        'archer_round_management.php',
        'equivalent_rounds_management.php',
        'equipment_class_management.php',
        'profile.php',
    ],
    ROLE_ARCHER => [
        'dashboard.php',
        'practicescore.php',
        'myscore.php',
        'personalbest.php',
        'roundinfo.php',
        'compresult.php',
        'profile.php',
    ],
];

$PUBLIC_PAGES = [
    'index.php',
    'home.php',
    'about_us.php',
    'login.php',
    'login_process.php',
    'logout.php',
    'register.php',
    'competitions.php',
    'news.php',
];

function current_page_name(): string
{
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if (!$path) {
        $path = $_SERVER['SCRIPT_NAME'] ?? '';
    }
    $base = basename($path);
    return $base ?: 'index.php';
}

/** Get the appropriate dashboard page for a given role. */
function user_dashboard_for_role(string $role): string
{
    return $role === ROLE_RECORDER ? 'recorder_dashboard.php' : 'dashboard.php';
}

/**
 * Is the user currently authenticated?
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']) && !empty($_SESSION['role']);
}

/**
 * Returns the current user's role (or null if not logged in)
 */
function current_role(): ?string
{
    return $_SESSION['role'] ?? null;
}

/**
 * Log a user in by setting session variables and regenerating the session ID.
 * $role must be one of ROLE_ARCHER or ROLE_RECORDER.
 */
function login_user($userId, string $role): void
{
    if (!in_array($role, [ROLE_ARCHER, ROLE_RECORDER], true)) {
        throw new InvalidArgumentException('Invalid role supplied to login_user');
    }

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }

    $_SESSION['user_id'] = $userId;
    $_SESSION['role'] = $role;
    $_SESSION['logged_in_at'] = time();
}

/**
 * Destroy the session and remove auth data
 */
function logout_user(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }
}

/**
 * Enforce access based on current page and the user's role/auth state.
 */
function enforce_access(): void
{
    global $ACCESS_RULES, $PUBLIC_PAGES;

    $page = current_page_name();
    $isPublic = in_array($page, $PUBLIC_PAGES);

    // Public pages - allow everyone
    if ($isPublic) {
        return;
    }

    // Not logged in - redirect to login
    if (!is_logged_in()) {
        header('Location: login.php?redirect=' . urlencode($page));
        exit;
    }

    // Logged in - check role permissions
    $userRole = current_role();

    // If user has no role, logout
    if (!$userRole) {
        logout_user();
        header('Location: login.php');
        exit;
    }

    // Check if user's role can access this page
    $allowedPages = $ACCESS_RULES[$userRole] ?? [];

    if (!in_array($page, $allowedPages)) {
        // User doesn't have permission - redirect to their dashboard
        header('Location: ' . user_dashboard_for_role($userRole) . '?denied=1');
        exit;
    }
}

/** Reliable redirect with fallback if headers already sent */
function redirect_and_exit(string $url): void
{
    if (!headers_sent()) {
        header('Location: ' . $url);
    } else {
        echo '<script>window.location.href=' . json_encode($url) . ';</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($url, ENT_QUOTES) . '"></noscript>';
    }
    exit;
}

// Auto-enforce access control
enforce_access();
