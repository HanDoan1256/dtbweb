
<?php  
// 1. Equipment List 
$equipment_options = [
    1 => 'Recurve',
    2 => 'Compound',
    3 => 'Recurve Barebow',
    4 => 'Compound Barebow',
    5 => 'Longbow',
];

// 2. Class List 

$class_options = [
    1 => 'Female Open',
    2 => 'Male Open',
    3 => '50+ Female',
    4 => '50+ Male',
    5 => '60+ Female',
    6 => '60+ Male',
    7 => '70+ Female',
    8 => '70+ Male',
    9 => 'Under 21 Female',
    10 => 'Under 21 Male',
    11 => 'Under 18 Female',
    12 => 'Under 18 Male',
    13 => 'Under 16 Female',
    14 => 'Under 16 Male',
    15 => 'Under 14 Female',
    16 => 'Under 14 Male',
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register | Archery Portal</title>
  <link rel="stylesheet" href="styles.css">
  
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Register New Archer</h1>
    <!-- Set method to POST and action to the current page for processing -->
    <form method="POST" action="register.php">
      
      <!-- User Account Credentials -->
      <fieldset>
        <legend>Account Credentials</legend>
        
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" maxlength="100" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="pass_word" maxlength="50" required>
        <br>
      </fieldset>
      <br>
      <br>
      <br>

      <!-- Archer Details -->
      <fieldset>
        <legend>Archer Profile Details</legend>
        
        <label for="name">Full Name:</label>
        <input type="text" id="name" name="name" maxlength="100" required>

        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" required>

        <label for="gender">Gender:</label>
        <select id="gender" name="gender" required>
          <option value="">-- Select Gender --</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
        </select>

        <label for="equipment">Default Equipment:</label>
        <select id="equipment" name="default_equipment_id" required>
          <option value="">-- Select Default Equipment --</option>
          <?php foreach ($equipment_options as $id => $name): ?>
            <option value="<?php echo $id; ?>"><?php echo htmlspecialchars($name); ?></option>
          <?php endforeach; ?>
        </select>

        <label for="class">Default Class:</label>
        <select id="class" name="class_id" required>
          <option value="">-- Select Default Class --</option>
          <?php foreach ($class_options as $id => $name): ?>
            <option value="<?php echo $id; ?>"><?php echo htmlspecialchars($name); ?></option>
          <?php endforeach; ?>
        </select>
      </fieldset>
      <br>
      <br>
      <br>
      <button type="submit">Create Archer Account</button>
    </form>
  </main>


  <?php include 'footer.inc'; ?>
</body>
</html>