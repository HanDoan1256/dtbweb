<?php
// simple helper to pass redirect param through the form
$redirect = $_GET['redirect'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Login | Archery Portal</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Login</h1>

    <?php if (isset($_GET['error'])): ?>
      <div class="error-message">
        <?php echo htmlspecialchars($_GET['error']); ?>
      </div>
    <?php endif; ?>

    <form method="post" action="login_process.php">
      <label>Username:</label>
      <input type="text" name="username" required>

      <label>Password:</label>
      <input type="password" name="password" required>

      <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($redirect, ENT_QUOTES); ?>">

      <button type="submit">Login</button>
    </form>
    <br>
    <br>
    <p class="registration-prompt">
      New archer? <a href="register.php">Register here</a>.
    </p>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>