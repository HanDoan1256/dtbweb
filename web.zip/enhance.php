<?php
session_start();

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Chat Assistant</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="styles.css">
</head>

<body id="enhancement">
    <?php include 'header.inc'; ?>

    <main class="chat-interface">
        <!-- API Status -->
        <div class="api-status">
            ✅ <strong>Groq AI Connected</strong> - Model: llama-3.1-8b-instant
        </div>

        <!-- Quick Suggestions -->
        <ul class="suggestions">
            <li class="suggestions-item">
                <span class="material-symbols-rounded">sports</span>
                <p class="text">Best archery equipment for beginners</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">tips_and_updates</span>
                <p class="text">How to improve archery accuracy</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">fitness_center</span>
                <p class="text">Proper archery form and technique</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">history_edu</span>
                <p class="text">History of archery sports</p>
            </li>
        </ul>

        <!-- Chat Messages -->
        <div class="chats-container" id="chatsContainer">
            <!-- Messages will be loaded here by JavaScript -->
        </div>

        <!-- Input Area -->
        <div class="prompt-container">
            <form class="prompt-form" id="promptForm">
                <input type="text" placeholder="Ask me anything..." class="prompt-input" id="promptInput" required>
                <div class="prompt-actions">
                    <button type="submit" id="send-prompts-btn" class="material-symbols-rounded">send</button>
                </div>
            </form>
            <p class="disclaimer-text">AI may occasionally generate inaccurate information</p>
        </div>
    </main>

    <script>
        // Real AI Connection
        const chatsContainer = document.getElementById("chatsContainer");
        const promptForm = document.getElementById("promptForm");
        const promptInput = document.getElementById("promptInput");
        const sendButton = document.getElementById("send-prompts-btn");
        let typingInterval = null;


        // Groq AI Configuration
        const API_KEY = "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";
        const API_URL = "https://api.groq.com/openai/v1/chat/completions";
        const MODEL = "llama-3.1-8b-instant";

        let chatHistory = [];
        let isGenerating = false;

        // Create message element
        const createMessage = (text, isUser = false) => {
            const messageDiv = document.createElement("div");
            messageDiv.className = `message ${isUser ? "user-message" : "bot-message"}`;

            if (isUser) {
                messageDiv.innerHTML = `<p class="message-text">${escapeHtml(text)}</p>`;
            } else {
                messageDiv.innerHTML = `
                    <div class="avatar">AI</div>
                    <p class="message-text">${escapeHtml(text)}</p>
                `;
            }

            return messageDiv;
        };

        const escapeHtml = (text) => {
            // Tạo element và set textContent để escape HTML
            const div = document.createElement("div");
            div.textContent = text;
            let safeText = div.innerHTML;

            // Chỉ thực hiện thay thế markdown cơ bản
            // **bold** -> <strong>bold</strong>
            safeText = safeText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            // *italic* -> <em>italic</em>  
            safeText = safeText.replace(/\*(.*?)\*/g, '<em>$1</em>');
            // Xuống dòng -> <br>
            safeText = safeText.replace(/\n/g, '<br>');

            return safeText;
        };

        // Scroll to bottom
        const scrollToBottom = () => {
            chatsContainer.scrollTop = chatsContainer.scrollHeight;
        };

        // Show typing effect
        const typeMessage = (text, element) => {
           if (typingInterval !== null) {
        clearInterval(typingInterval);
        typingInterval = null;
    }

    element.innerHTML = "";
    let index = 0;

    typingInterval = setInterval(() => {
        if (index < text.length) {
            element.innerHTML += text.charAt(index);
            index++;
            scrollToBottom();
        } else {
            clearInterval(typingInterval);
            typingInterval = null;
        }
    }, 20);
};

        // Real AI API Call
        const getAIResponse = async (userMessage) => {
            // Add to chat history
            chatHistory.push({
                role: "user",
                content: userMessage,
            });

            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${API_KEY}`,
                },
                body: JSON.stringify({
                    model: MODEL,
                    messages: [{
                            role: "system",
                            content: `You are an AI assistant for an Archery Management System. 
                            This web application helps archers track scores, manage competitions, 
                            and improve their archery skills.

CONTEXT:
- This is an archery management web application
- Users can submit practice scores, view personal bests, track competitions
- Features include: score tracking, competition management, equipment management, class categories
- Archery rounds include: WA90/1440, WA70/1440, Portsmouth, Sydney, Brisbane, etc.
- Equipment types: Recurve, Compound, Barebow, Longbow
- Age classes: Open, 50+, 60+, 70+, Under 21, Under 18, Under 16, Under 14

YOUR ROLE:
- Provide expert advice on archery techniques, equipment, training, and competitions
- Help users understand archery rules, scoring, and round specifications
- Assist with equipment selection and maintenance tips
- Offer training exercises and form improvement suggestions
- Explain competition formats and preparation strategies
- Be encouraging and supportive of archers at all skill levels

RESPONSE GUIDELINES:
- Use archery terminology appropriately
- Provide practical, actionable advice
- Be specific about equipment, techniques, and training methods
- Reference common archery rounds and competitions when relevant
- Use emojis related to sports and archery 🎯🏹🥇
- Format responses clearly with paragraphs and bullet points when helpful
- If unsure, admit it and suggest consulting a certified coach`,
                        },
                        ...chatHistory.slice(-6), // Keep last 6 messages for context
                    ],
                    max_tokens: 1024,
                    temperature: 0.7,
                    stream: false,
                }),
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const data = await response.json();

            if (!data.choices || !data.choices[0].message.content) {
                throw new Error("Invalid response format");
            }

            const aiResponse = data.choices[0].message.content;

            // Add to chat history
            chatHistory.push({
                role: "assistant",
                content: aiResponse,
            });

            // Limit history size
            if (chatHistory.length > 10) {
                chatHistory = chatHistory.slice(-10);
            }

            return aiResponse;
        };

        // Handle form submission
        promptForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            
            // Stop typing immediately when a new message is submitted
            if (typingInterval !== null) {
                clearInterval(typingInterval);
                typingInterval = null;
            }

            const userMessage = promptInput.value.trim();
            if (!userMessage || isGenerating) return;

            // Clear input
            promptInput.value = "";
            isGenerating = true;
            sendButton.disabled = true;

            // Add user message
            const userMessageElement = createMessage(userMessage, true);
            chatsContainer.appendChild(userMessageElement);
            scrollToBottom();

            // Show loading message
            const loadingMessage = createMessage("Thinking...", false);
            loadingMessage.classList.add("loading");
            chatsContainer.appendChild(loadingMessage);
            scrollToBottom();

            try {
                // Get real AI response
                const aiResponse = await getAIResponse(userMessage);

                // Remove loading message
                loadingMessage.remove();

                // Add AI response with typing effect
                const aiMessageElement = createMessage("", false);
                chatsContainer.appendChild(aiMessageElement);
                const messageText = aiMessageElement.querySelector(".message-text");
                typeMessage(aiResponse, messageText);
            } catch (error) {
                console.error("AI Error:", error);
                loadingMessage.remove();
                const errorMessage = createMessage(
                    "Sorry, I'm having trouble connecting right now. Please try again in a moment! 🔧",
                    false
                );
                chatsContainer.appendChild(errorMessage);
            } finally {
                isGenerating = false;
                sendButton.disabled = false;
                promptInput.focus();
            }
        });

        // Quick suggestions click
        document.querySelectorAll(".suggestions-item").forEach((item) => {
            item.addEventListener("click", () => {
                const text = item.querySelector(".text").textContent;
                promptInput.value = text;
                promptInput.focus();

                // Auto-submit after short delay
                setTimeout(() => {
                    if (!isGenerating) {
                        promptForm.dispatchEvent(new Event("submit"));
                    }
                }, 100);
            });
        });

        // Enter key to send
        promptInput.addEventListener("keypress", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                promptForm.dispatchEvent(new Event("submit"));
            }
        });

        // Input validation
        promptInput.addEventListener("input", () => {
            sendButton.disabled = promptInput.value.trim() === "" || isGenerating;
        });

        // Initialize chat
        window.addEventListener("load", () => {
            promptInput.focus();

            // Welcome message
            const welcomeMessage = createMessage(
                "Hello! 👋 I'm your AI assistant powered by Groq. I can help you with programming, web development, design, career advice, or anything else you'd like to discuss! \n\nFeel free to ask me anything or click the suggestions above to get started. 🚀",
                false
            );
            chatsContainer.appendChild(welcomeMessage);

            // Add to chat history
            chatHistory.push({
                role: "assistant",
                content: "Hello! I'm your AI assistant. How can I help you today?",
            });

            scrollToBottom();
        });

        // Clear chat function
        window.clearChat = () => {
            chatsContainer.innerHTML = "";
            chatHistory = [];

            const welcomeMessage = createMessage(
                "Hello! 👋 Chat cleared. I'm ready to help you with a new conversation! What would you like to know?",
                false
            );
            chatsContainer.appendChild(welcomeMessage);

            chatHistory.push({
                role: "assistant",
                content: "Hello! Chat cleared. I'm ready to help you with a new conversation!",
            });

            promptInput.focus();
        };
    </script>
</body>

</html>