<?php
session_start();
require_once 'connection.php';

echo "<h2>Debug Login</h2>";

if ($_POST) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    echo "Username: " . htmlspecialchars($username) . "<br>";
    echo "Password: " . htmlspecialchars($password) . "<br>";

    // Kiểm tra database
    $stmt = $conn->prepare('SELECT username, pass_word, user_role, archer_id FROM accounts WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo "User found in database<br>";
        echo "Stored password: " . $row['pass_word'] . "<br>";
        echo "User role: " . $row['user_role'] . "<br>";

        $stored = $row['pass_word'];
        $ok = false;

        if (password_verify($password, $stored)) {
            $ok = true;
            echo "Password verified via password_verify<br>";
        } elseif ($stored === $password) {
            $ok = true;
            echo "Password verified via plain text<br>";
        } else {
            echo "Password verification FAILED<br>";
        }

        if ($ok) {
            $_SESSION['user_id'] = $row['archer_id'] ?? $row['username'];
            $_SESSION['role'] = $row['user_role'];
            echo "Login SUCCESS - Session set<br>";
            echo "<a href='dashboard.php'>Go to Dashboard</a>";
        }
    } else {
        echo "User NOT found in database<br>";
    }
}
?>

<form method="post">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Test Login</button>
</form>