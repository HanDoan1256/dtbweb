<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>View Table Data</title>
  <link rel="stylesheet" href="styles.css" />
  <style>
    .table-container {
      width: 95%;
      max-width: 1400px;
      margin: 20px auto;
      overflow-x: auto;
    }

    .data-table {
      border-collapse: collapse;
      margin: 20px auto;
      text-align: left;
      width: 100%;
      background-color: #2a2a2a;
      color: #eee;
    }

    .data-table th,
    .data-table td {
      border: 1px solid #444;
      padding: 10px 12px;
      white-space: nowrap;
    }


    .data-table th {
      color: #fff !important; 
    }


    .data-table thead tr {
      background-color: #d32f2f;

      text-transform: uppercase;
    }

    .data-table tbody tr:nth-child(even) {
      background-color: #222;
    }

    .data-table tbody tr:hover {
      background-color: #333;
    }

    .back-link {
      display: inline-block;
      margin: 10px 0 20px 2.5%;
      color: #d32f2f;
      text-decoration: none;
      font-size: 1.1em;
    }

    .back-link:hover {
      text-decoration: underline;
    }

    .no-data {
      padding: 30px;
      text-align: center;
      font-size: 1.2em;
      color: #888;
    }

/* Container for all charts - uses Flexbox for responsive alignment */
    .chart-gallery {
      display: flex;
      flex-wrap: wrap; /* Allows charts to wrap to the next line on smaller screens */
      gap: 1rem; /* Space between the charts */
      justify-content: center; /* Center the charts horizontally */
      margin-bottom: 30px;
      padding: 10px;
      background-color: #1a1a1a; /* Dark background for the chart area */
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    /* Individual chart item styling */
    .chart-item {
      flex: 1 1 45%; /* Default: allow 2 charts per row (45% width each) */
      min-width: 250px; /* Minimum width before wrapping */
      overflow: hidden;
      border-radius: 6px;
      background-color: #222;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
    }

    /* Chart image styling */
    .chart-item img {
      display: block;
      width: 100%;
      height: auto;
      object-fit: contain; /* Ensures the whole chart is visible without cropping */
      transition: transform 0.3s ease-in-out;
    }

    /* Hover effect for a cleaner interaction */
    .chart-item:hover img {
      transform: scale(1.02);
      opacity: 0.9;
    }

    /* Media query for smaller screens (mobile) */
    @media (max-width: 768px) {
      .chart-item {
        flex: 1 1 100%; /* Only 1 chart per row on mobile */
      }
    }
    
    .chart-gallery-title {
        color: #ddd;
        text-align: center;
        margin: 0 0 15px 0;
        font-weight: 500;
        font-size: 1.4em;
    }

  </style>
</head>

<body>
  <?php
  include 'header.inc';
  require_once 'connection.php';

  $allowedTables = [
    'accounts', 'archers', 'classes', 'competitions', 'competition_results',
    'equipment', 'equivalent_rounds', 'practice_score', 'ranges', 'rounds',
    'scores', 'score_details', 'staging_scores'
  ];

// --- Chart Configuration ---
  $tableCharts = [
    'archers' => [
        'charts/archer/age.png' => 'Age Distribution',
        'charts/archer/equip.png' => 'Equipment Usage',
        'charts/archer/gender.png' => 'Gender Ratio',
        'charts/archer/class.png' => 'Archer Classes'
    ],
    'scores' => [
        'charts/scores/agescore.png' => 'Age vs. Score',
        'charts/scores/equipscore.png' => 'Score by Equipment',
        'charts/scores/classscore.png' => 'Score by Class',
        'charts/scores/top15.png' => 'Top 15 Scores' 
    ],
    'equipment' => [
        'charts/equip/compound.png' => 'Compound Bow Stats',
        'charts/equip/recurve.png' => 'Recurve Bow Stats',
        'charts/equip/longbow.png' => 'Longbow Stats',
        'charts/equip/recurvebare.png' => 'Recurve Barebow Stats'
    ],
    'competitions' => [
        'charts/competitions/award.png' => 'Awards Distribution',
        'charts/competitions/equip.png' => 'Equipment in Competitions',
        'charts/competitions/join.png' => 'Participation Trends',
        'charts/competitions/timeline.png' => 'Competition Timeline'
    ],
    'competition_results' => [
        'charts/result/avgrank.png' => 'Average Ranking',
        'charts/result/avgscore.png' => 'Average Score',
        'charts/result/distribution.png' => 'Results Distribution'
    ]
  ];
  // --------------------------------

  $tableName = $_GET['table_name'] ?? '';
  $tableData = [];
  $tableHeaders = [];
  $errorMsg = '';


  if (!empty($tableName) && in_array($tableName, $allowedTables)) {

    $sql = "SELECT * FROM `$tableName`";

    $result = $conn->query($sql);

    if ($result) {


      $fields = $result->fetch_fields();
      foreach ($fields as $field) {
        $tableHeaders[] = $field->name;
      }

      while ($row = $result->fetch_assoc()) {
        $tableData[] = $row;
      }
      $result->close();
    } else {

      $errorMsg = "Fail query: " . $conn->error;
    }
  } else if (empty($tableName)) {

    $errorMsg = "Have not selected any table. Please go back to the dashboard.";
  } else {

    $errorMsg = "Inappropriate table name.";
  }

  $conn->close();
  ?>

  <main>
    <section class="table-container">
      

      <a href="table_select_dashboard.php" class="back-link">&larr; Choose Another Table</a>

      <h2 style="color: #fefefe;">

        Data from table: <span style="color: #d32f2f;"><?php echo htmlspecialchars($tableName); ?></span>
      </h2>

      <!--CHART DISPLAY -->
      <?php 
        // Check if the current table has defined charts and there are no general errors
        if (!empty($tableName) && empty($errorMsg) && isset($tableCharts[$tableName])) : 
          $charts = $tableCharts[$tableName];
      ?>
          <h3 class="chart-gallery-title">Visualizations for <?php echo htmlspecialchars(ucfirst($tableName)); ?></h3>
          <div class="chart-gallery">
            <?php 
              foreach ($charts as $path => $alt) : 
                // Using $path as the src and $alt as the alt text
            ?>
              <div class="chart-item">
                <img 
                  src="<?php echo htmlspecialchars($path); ?>" 
                  alt="Chart: <?php echo htmlspecialchars($alt); ?>" 
                  loading="lazy"
                >
              </div>
            <?php endforeach; ?>
          </div>
      <?php endif; ?>
      <!-- --------------------------------- -->


      <?php if (!empty($errorMsg)) : ?>
        <p class="no-data"><?php echo $errorMsg; ?></p>

      <?php else : ?>

        <table class="data-table">
          <thead>
            <tr>
              <?php

              if (!empty($tableHeaders)) {
                foreach ($tableHeaders as $header) {
                  echo '<th>' . htmlspecialchars($header) . '</th>';
                }
              }
              ?>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($tableData)) : ?>

              <tr>
                <td colspan="<?php echo count($tableHeaders); ?>" style="text-align: center; padding: 20px; color: #888;">
                  No data in this table.
                </td>
              </tr>
            <?php else : ?>
              <?php foreach ($tableData as $row) : ?>
                <tr>
                  <?php foreach ($row as $data) : ?>
                    <td><?php echo htmlspecialchars($data ?? 'NULL'); ?></td>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      <?php endif; ?>

    </section>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>