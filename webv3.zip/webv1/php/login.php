<?php
// simple helper to pass redirect param through the form
$redirect = $_GET['redirect'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | Archery Portal</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Recorder Login</h1>
    <form method="post" action="login_process.php">
      <label>username:</label>
      <input type="username" name="username" required>

      <label>Password:</label>
      <input type="password" name="password" required>

      <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($redirect, ENT_QUOTES); ?>">

      <button type="submit">Login</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>