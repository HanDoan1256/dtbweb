<?php
require_once 'connection.php';

// Lấy danh sách rounds từ database để hiển thị trong dropdown
$rounds_result = $conn->query("SELECT * FROM rounds ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Competition Management</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Competition Management</h1>

    <!-- Form thêm competition -->
    <div style="background: #191a1bff; padding: 20px; margin-bottom: 30px; border-radius: 8px;">
      <h2>Add New Competition</h2>
      <form action="competition_management.php" method="post">
        <label>Competition Name:</label>
        <input type="text" name="name" required>

        <label>Date:</label>
        <input type="date" name="date" required>

        <label>Base Round:</label>
        <select name="base_round_id" required>
          <option value="">Select Base Round</option>
          <?php
          $rounds_result->data_seek(0); // Reset pointer
          while ($round = $rounds_result->fetch_assoc()): ?>
            <option value="<?php echo $round['round_id']; ?>">
              <?php echo htmlspecialchars($round['name']); ?>
            </option>
          <?php endwhile; ?>
        </select>

        <label>Is Championship:</label>
        <input type="checkbox" name="is_championship" value="1"> Yes

        <button type="submit" name="add_competition">Add Competition</button>
      </form>
    </div>

    <!-- Hiển thị danh sách competitions -->
    <div style="background: #191a1bff; padding: 20px; border-radius: 8px;">
      <h2>Existing Competitions</h2>
      <?php
      $competitions_query = "
          SELECT c.*, r.name as round_name 
          FROM competitions c 
          JOIN rounds r ON c.base_round_id = r.round_id 
          ORDER BY c.date DESC
      ";
      $competitions_result = $conn->query($competitions_query);

      if ($competitions_result && $competitions_result->num_rows > 0) {
        echo '<table border="1" style="border-collapse: collapse; width: 100%;">';
        echo '<tr style="background-color: #e9ecef;">';
        echo '<th>Name</th><th>Date</th><th>Base Round</th><th>Championship</th>';
        echo '</tr>';

        while ($comp = $competitions_result->fetch_assoc()) {
          $championship = $comp['is_championship'] ? '🏆 Yes' : 'No';
          echo '<tr>';
          echo '<td>' . htmlspecialchars($comp['name']) . '</td>';
          echo '<td>' . $comp['date'] . '</td>';
          echo '<td>' . htmlspecialchars($comp['round_name']) . '</td>';
          echo '<td style="text-align: center;">' . $championship . '</td>';
          echo '</tr>';
        }
        echo '</table>';
      } else {
        echo '<p>No competitions found.</p>';
      }
      ?>
    </div>

    <?php
    // Xử lý thêm competition
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_competition'])) {
      $name = trim($_POST['name']);
      $date = $_POST['date'];
      $base_round_id = $_POST['base_round_id'];
      $is_championship = isset($_POST['is_championship']) ? 1 : 0;

      if (!empty($name) && !empty($date) && !empty($base_round_id)) {
        $sql = "INSERT INTO competitions (name, date, is_championship, base_round_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssii", $name, $date, $is_championship, $base_round_id);

        if ($stmt->execute()) {
          echo "<p style='color: green;'>Competition added successfully!</p>";
          // Refresh trang để hiển thị competition mới
          echo "<script>setTimeout(() => window.location.reload(), 1000);</script>";
        } else {
          echo "<p style='color: red;'>Error adding competition: " . $conn->error . "</p>";
        }

        $stmt->close();
      } else {
        echo "<p style='color: red;'>Please fill all required fields</p>";
      }
    }

    $conn->close();
    ?>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>