<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Equivalent Rounds Management</title>
  <link rel="stylesheet" href="styles.css">
  
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Equivalent Rounds</h1>
    <form>
      <label>Round:</label><input type="text">
      <label>Equivalent Round:</label><input type="text">
      <label>Valid From:</label><input type="date">
      <label>Valid To:</label><input type="date">
      <button>Save</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>