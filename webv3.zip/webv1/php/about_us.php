<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meet the Team</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <?php include 'header.inc'; ?>
<main>
    <section class="intro">
        <div class="image-container">
            <img src="images/grouppic.png" alt="Team Picture">
            <h1>MEET THE TEAM</h1>
        </div>
    </section>
    
    
    <h2 class="abth2"> <span class="abt2light">DEFINITION</span> LIST</h2>
    <section class="definition-container">
        <div class="definition">
        <dl>
            <dt>Group Name</dt>
            <dd>Otomatic</dd>

            <dt>Group information</dt>
            <dd><a href="#">otomatic2025@gmail.com</a></dd>

            <dt>Tutor's name</dt>
            <dd><a href="#">Wilson Doan</a></dd>

            <dt>Nguyen Huu Thien Khang</dt>
            <dd>Contribute_abc</dd>

            <dt>Doan Gia Han</dt>
            <dd>Contribute_abc</dd>

            <dt>Ngo Quynh Nhu</dt>
            <dd>Contribute_abc</dd>

            <dt>Do Duc Duy</dt>
            <dd>Contribute_abc</dd>

            <dt>Nguyen Trong Tin</dt>
            <dd>Contribute_abc</dd>

 
        </dl>
        </div>
        
    </section>

    <section class="team-container">
        
        <div class="team-member">
            <img src="images/khang.jpg" alt="Nguyen Huu Thien Khang">
            <div id="TK" class="team-info">
                <h3>Nguyen Huu Thien Khang</h3>
                <p>Student ID: 105507230</p>
                <p>Email: <a href="#">khang@gmail.com</a></p>
                <p>Major: ...</p>
            </div>
        </div>

        <div class="team-member">
            <img src="images/han.jpg" alt="Doan Gia Han">
            <div id="GH" class="team-info">
                <h3>Doan Gia Han</h3>
                <p>Student ID: 105506817</p>
                <p>Email: <a href="mailto:handoangia2612@gmail.com">handoangia2612@gmail.com</a></p>
                <p>Major: Data Science</p>
            </div>
        </div>

        <div class="team-member">
            <img src="images/nhu.png" alt="Ngo Quynh Nhu">
            <div id="QN" class="team-info">
                <h3>Ngo Quynh Nhu</h3>
                <p>Student ID: 105312140</p>
                <p>Email: <a href="mailto:quynhnhungo06@gmail.com">quynhnhungo06@gmail.com</a></p>
                <p>Major: Cyber Security</p>
            </div>
        </div>

        <div class="team-member">
            <img src="images/duy.jpg" alt="Do Duc Duy">
            <div id="DD" class="team-info">
                <h3>Do Duc Duy</h3>
                <p>Student ID: 105507244</p>
                <p>Email: <a href="#">duy@gmail.com</a></p>
                <p>Major: ...</p>            
        </div>

        </div>
        <div class="team-member">
            <img src="images/tin.jpg" alt="Nguyen Trong Tin">
            <div id="NT" class="team-info">
                <h3>Nguyen Trong Tin</h3>
                <p>Student ID: 105507233</p>
                <p>Email: <a href="#">tin@gmail.com</a></p>
                <p>Major: ...</p>
            </div>
        </div>
    </section>

    
    <br>
    <br>
    <br>
    <br>
    <hr/>
</main>
    <?php include 'footer.inc'; ?>
</body>
</html>
