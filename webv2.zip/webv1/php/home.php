<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <link rel="stylesheet" href="styles.css" />
</head>

<body>
  <?php include 'header.inc'; ?>

  <?php
  // Include database connection
  require_once 'connection.php';

  // Lấy dữ liệu top archers - tháng 10/2025
  $query = "
      SELECT 
          a.name AS archer_name,
          a.archer_id,
          MAX(s.total_score) AS highest_score,
          e.name AS equipment_name,
          c.name AS class_name
      FROM scores s
      INNER JOIN archers a ON s.archer_id = a.archer_id
      INNER JOIN equipment e ON s.equipment_id = e.equipment_id
      INNER JOIN classes c ON a.class_id = c.class_id
      WHERE YEAR(s.datetime) = 2025 AND MONTH(s.datetime) = 10
      GROUP BY a.archer_id, a.name, e.name, c.name
      ORDER BY highest_score DESC
      LIMIT 6
  ";

  $stmt = $conn->prepare($query);
  $stmt->execute();
  $result = $stmt->get_result();
  $topArchers = $result->fetch_all(MYSQLI_ASSOC);
  ?>

  <main>
    <section class="intro">
      <div class="image">
        <img src="archer.png" alt="Archer background">
      </div>
    </section>

    <section class="top-archer">
      <div class="lb-head">
        <h2 id="lb-title">TOP ARCHERS - OCTOBER 2025</h2>
        <div class="lb-range">(Current season performance)</div>
      </div>

      <div class="table-container">
        <table border="1" width="90%" style="border-collapse: collapse; margin: 20px auto; text-align: center;">
          <thead>
            <tr style="background-color: #f2f2f2;">
              <th width="10%">Rank</th>
              <th width="25%">Archer Name</th>
              <th width="20%">Class</th>
              <th width="20%">Equipment</th>
              <th width="25%">Highest Score</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if (!empty($topArchers)) {
              $rank = 1;
              foreach ($topArchers as $archer) {
                echo '
                    <tr>
                      <td><strong>' . $rank . '</strong></td>
                      <td>' . htmlspecialchars($archer['archer_name']) . '</td>
                      <td>' . htmlspecialchars($archer['class_name']) . '</td>
                      <td>' . htmlspecialchars($archer['equipment_name']) . '</td>
                      <td><strong>' . htmlspecialchars($archer['highest_score']) . '</strong></td>
                    </tr>';
                $rank++;
              }
            } else {
              echo '
                <tr>
                  <td colspan="5" style="padding: 20px; color: #666;">No data available for October 2025</td>
                </tr>';
            }
            ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <?php
  $stmt->close();
  $conn->close();
  include 'footer.inc';
  ?>
</body>

</html>