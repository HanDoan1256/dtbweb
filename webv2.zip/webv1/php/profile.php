<?php
require_once 'connection.php';
require_once 'manage_access.php';

// Check if user is logged in
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}

// Get the logged-in user's ID from session
$userId = $_SESSION['user_id'];

// Fetch archer profile data from database
$profile = null;
if ($conn && !$conn->connect_error) {
    $query = "
        SELECT 
            a.archer_id,
            a.name,
            a.dob,
            a.gender,
            e.name as equipment_name,
            c.name as class_name
        FROM accounts acc
        INNER JOIN archers a ON acc.archer_id = a.archer_id
        LEFT JOIN equipment e ON a.default_equipment_id = e.equipment_id
        LEFT JOIN classes c ON a.class_id = c.class_id
        WHERE acc.username = ? OR acc.archer_id = ?
    ";
    
    $stmt = $conn->prepare($query);
    
    // Bind parameters based on whether user_id is archer_id or username
    if (is_numeric($userId)) {
        $stmt->bind_param("ii", $userId, $userId);
    } else {
        $stmt->bind_param("ss", $userId, $userId);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $profile = $result->fetch_assoc();
    $stmt->close();
}

function formatDate($date) {
    if (!$date || $date == '0000-00-00') return '—';
    return date('M j, Y', strtotime($date));
}

function e($s) { 
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archery Management — Profile</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
<?php include 'header.inc'; ?>

<main>
    <section id="profile" class="profile-section">
        <div class="profile-header">
            <h1>My Profile</h1>
            <a href="logout.php" class="logout-btn">Log Out</a>
        </div>
        
        <?php if ($profile): ?>
            <div class="profile-info">
                <div class="profile-field">
                    <strong>Archer ID:</strong> <span><?= e($profile['archer_id']) ?></span>
                </div>
                <div class="profile-field">
                    <strong>Name:</strong> <span><?= e($profile['name']) ?></span>
                </div>
                <div class="profile-field">
                    <strong>Date of Birth:</strong> <span><?= e(formatDate($profile['dob'])) ?></span>
                </div>
                <div class="profile-field">
                    <strong>Gender:</strong> <span><?= e($profile['gender']) ?></span>
                </div>
                <div class="profile-field">
                    <strong>Default Equipment:</strong> <span><?= e($profile['equipment_name'] ?? 'Not set') ?></span>
                </div>
                <div class="profile-field">
                    <strong>Class:</strong> <span><?= e($profile['class_name'] ?? 'Not set') ?></span>
                </div>
            </div>
        <?php else: ?>
            <div class="profile-error">
                <p>Profile information not available.</p>
                <?php if (!$conn || $conn->connect_error): ?>
                    <p><em>Database connection issue - please try again later.</em></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
</main>

<?php include 'footer.inc'; ?>
</body>
</html>