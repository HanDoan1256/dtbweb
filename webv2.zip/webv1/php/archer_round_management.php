<?php
require_once 'connection.php';

// Lấy danh sách equipment và classes từ database
$equipment_result = $conn->query("SELECT * FROM equipment");
$classes_result = $conn->query("SELECT * FROM classes");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Archer & Round Management</title>
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Archer & Round Management</h1>

    <form action="archer_management.php" method="post">
      <h2>Add New Archer</h2>

      <label>Name:</label>
      <input type="text" name="name" required>

      <label>DOB:</label>
      <input type="date" name="dob" required>

      <label>Gender:</label>
      <select name="gender" required>
        <option value="">Select Gender</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>

      <label>Default Equipment:</label>
      <select name="default_equipment_id" required>
        <option value="">Select Equipment</option>
        <?php while ($equipment = $equipment_result->fetch_assoc()): ?>
          <option value="<?php echo $equipment['equipment_id']; ?>">
            <?php echo htmlspecialchars($equipment['name']); ?>
          </option>
        <?php endwhile; ?>
      </select>

      <label>Class:</label>
      <select name="class_id" required>
        <option value="">Select Class</option>
        <?php while ($class = $classes_result->fetch_assoc()): ?>
          <option value="<?php echo $class['class_id']; ?>">
            <?php echo htmlspecialchars($class['name']); ?>
          </option>
        <?php endwhile; ?>
      </select>

      <button type="submit" name="add_archer">Add Archer</button>
    </form>

    <?php
    // Xử lý thêm archer
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_archer'])) {
      $name = trim($_POST['name']);
      $dob = $_POST['dob'];
      $gender = $_POST['gender'];
      $default_equipment_id = $_POST['default_equipment_id'];
      $class_id = $_POST['class_id'];

      if (!empty($name) && !empty($dob) && !empty($gender) && !empty($default_equipment_id) && !empty($class_id)) {
        $sql = "INSERT INTO archers (name, dob, gender, default_equipment_id, class_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssii", $name, $dob, $gender, $default_equipment_id, $class_id);

        if ($stmt->execute()) {
          echo "<p style='color: green;'>Archer added successfully!</p>";
        } else {
          echo "<p style='color: red;'>Error adding archer: " . $conn->error . "</p>";
        }

        $stmt->close();
      } else {
        echo "<p style='color: red;'>Please fill all fields</p>";
      }
    }

    $conn->close();
    ?>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>