<?php
$servername = "localhost";
$username = "root";
$password = ""; // Leave empty if no password
$database = "archery_dtb";

// For Homebrew MySQL on Mac, use the socket path
$socket = '/tmp/mysql.sock'; // or try '/var/mysql/mysql.sock'

// Try connecting with socket
$conn = new mysqli($servername, $username, $password, $database, null, $socket);

if ($conn->connect_error) {
    // If socket fails, try regular connection
    $conn = new mysqli($servername, $username, $password, $database, 3306);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
}
?>