<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Recorder Dashboard</title>
  <link rel="stylesheet" href="styles.css">
  
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Recorder Dashboard</h1>
    <section>
      <h2>Quick Stats</h2>
      <ul>
        <li>Pending Scores: 5</li>
        <li>Upcoming Competitions: 2</li>
        <li>Total Archers: 45</li>
      </ul>
    </section>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>