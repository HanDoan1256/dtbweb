<?php
require_once 'connection.php';
require_once 'manage_access.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$redirect = trim($_POST['redirect'] ?? $_GET['redirect'] ?? '');
$error = '';

if ($username === '' || $password === '') {
    $error = 'Please enter both username and password.';
} else {
    // CORRECTED QUERY - matches your database schema
    $stmt = $conn->prepare('SELECT username, pass_word, user_role, archer_id FROM accounts WHERE username = ?');
    if ($stmt === false) {
        $error = 'Server error (DB prepare failed).';
    } else {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $stored = $row['pass_word']; // Changed from 'password' to 'pass_word'
            $ok = false;
            
            // Prefer password hashing, but allow legacy plain text as fallback
            if (password_verify($password, $stored)) {
                $ok = true;
            } elseif (hash_equals($stored, $password)) {
                $ok = true;
            }

            if ($ok) {
                // Choose user id: prefer archer_id, fallback to username
                $userId = $row['archer_id'] ?? $row['username'];
                // Use the centralized login helper which regenerates session id
                login_user($userId, $row['user_role']); // Changed from 'role' to 'user_role'

                // sanitize redirect: only allow simple relative paths
                if ($redirect && preg_match('#^[A-Za-z0-9_\-\/\.]+$#', $redirect)) {
                    header('Location: ' . $redirect);
                } else {
                    header('Location: ' . user_dashboard_for_role($row['user_role'])); // Changed from 'role' to 'user_role'
                }
                exit;
            } else {
                $error = 'Invalid password.';
            }
        } else {
            $error = 'Username not found.';
        }
    }
}

// On errors, send back to login page with message and preserve redirect
$params = ['error' => $error];
if ($redirect) $params['redirect'] = $redirect;
header('Location: login.php?' . http_build_query($params));
exit;
?>