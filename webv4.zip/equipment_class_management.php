<?php  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Equipment & Class Management</title>
  <link rel="stylesheet" href="styles.css">
  
</head>

<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Equipment & Class Management</h1>

    <form action="equipment_class_management.php" method="post">
      <h2>Add Equipment</h2>
      <label>Equipment Name:</label><input type="text" name="equipment_name" required>
      <button type="submit" name="add_equipment">Add Equipment</button>
    </form>
    <?php
    require_once 'connection.php';

    // Xử lý thêm equipment
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_equipment'])) {
      $equipmentName = trim($_POST['equipment_name']);

      if (!empty($equipmentName)) {

        $sql = "INSERT INTO equipment (name) VALUES (?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $equipmentName);

        if ($stmt->execute()) {
          echo "<p style='color: green;'>Equipment added successfully!</p>";
        } else {
          echo "<p style='color: red;'>Error adding equipment: " . $conn->error . "</p>";
        }

        $stmt->close();
      }
    }
    ?>


    <form>
      <h2>Update Class Rules</h2>
      <label>Class Name:</label><input type="text">
      <label>Class type:</label><select>
        <option>A</option>
        <option>B</option>
      </select>
      <button>Update Class</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>

</html>