<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Chat Assistant</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="styles.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: inherit;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .api-status {
            background: rgba(232, 245, 232, 0.9);
            color: #2e7d32;
            padding: 10px 15px;
            margin: 15px;
            border-radius: 10px;
            text-align: center;
            border-left: 4px solid #4caf50;
            font-size: 14px;
            backdrop-filter: blur(10px);
        }

        .chat-interface {
            flex: 1;
            display: flex;
            flex-direction: column;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
            padding: 0 15px;
        }

        .suggestions {
            display: flex;
            gap: 10px;
            padding: 15px;
            margin: 0;
            overflow-x: auto;
            flex-wrap: nowrap;
        }

        .suggestions-item {
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid #e9ecef;
            border-radius: 20px;
            padding: 12px 18px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
            backdrop-filter: blur(10px);
            flex-shrink: 0;
        }

        .suggestions-item:hover {
            background: #007bff;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.3);
        }

        .suggestions-item .text {
            margin: 0;
            font-size: 14px;
            color: inherit;
        }

        .chats-container {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            display: flex;
            flex-direction: column;
            gap: 15px;
            min-height: 300px;
        }

        .message {
            padding: 12px 18px;
            border-radius: 18px;
            max-width: 80%;
            animation: fadeIn 0.3s ease;
            line-height: 1.5;
            word-wrap: break-word;
        }

        .user-message {
            background: #007bff;
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 5px;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
        }

        .bot-message {
            background: rgba(255, 255, 255, 0.9);
            color: #333;
            margin-right: auto;
            border-bottom-left-radius: 5px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .bot-message .avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            flex-shrink: 0;
            background: #007bff;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }

        .message-text {
            margin: 0;
            line-height: 1.5;
        }

        .message.loading .message-text {
            color: #6c757d;
            font-style: italic;
        }

        .prompt-container {
            padding: 20px 15px;
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .prompt-form {
            display: flex;
            gap: 12px;
            align-items: flex-end;
            max-width: 800px;
            margin: 0 auto;
        }

        .prompt-input {
            flex: 1;
            padding: 15px 20px;
            border: 2px solid #e9ecef;
            border-radius: 25px;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
            background: white;
            font-family: inherit;
        }

        .prompt-input:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
        }

        .prompt-actions button {
            background: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            font-size: 20px;
        }

        .prompt-actions button:hover:not(:disabled) {
            background: #0056b3;
            transform: scale(1.05);
        }

        .prompt-actions button:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }

        .disclaimer-text {
            text-align: center;
            font-size: 12px;
            color: #6c757d;
            margin: 10px 0 0 0;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .chat-interface {
                padding: 0 10px;
            }

            .suggestions {
                padding: 10px;
                gap: 8px;
            }

            .suggestions-item {
                padding: 10px 15px;
                font-size: 13px;
            }

            .message {
                max-width: 90%;
                padding: 10px 15px;
            }

            .chats-container {
                padding: 10px;
                gap: 12px;
            }

            .prompt-input {
                padding: 12px 18px;
                font-size: 14px;
            }

            .prompt-actions button {
                width: 45px;
                height: 45px;
            }
        }

        @media (max-width: 480px) {
            .suggestions {
                flex-direction: column;
                overflow-x: visible;
            }

            .suggestions-item {
                white-space: normal;
                text-align: center;
                justify-content: center;
            }

            .message {
                max-width: 95%;
            }

            .api-status {
                margin: 10px;
                font-size: 13px;
            }
        }
    </style>
</head>

<body id="enhancement">
    <?php include 'header.inc'; ?>

    <main class="chat-interface">
        <!-- API Status -->
        <div class="api-status">
            ✅ <strong>Groq AI Connected</strong> - Model: llama-3.1-8b-instant
        </div>

        <!-- Quick Suggestions -->
        <ul class="suggestions">
            <li class="suggestions-item">
                <span class="material-symbols-rounded">sports</span>
                <p class="text">Best archery equipment for beginners</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">tips_and_updates</span>
                <p class="text">How to improve archery accuracy</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">fitness_center</span>
                <p class="text">Proper archery form and technique</p>
            </li>
            <li class="suggestions-item">
                <span class="material-symbols-rounded">history_edu</span>
                <p class="text">History of archery sports</p>
            </li>
        </ul>

        <!-- Chat Messages -->
        <div class="chats-container" id="chatsContainer">
            <!-- Messages will be loaded here by JavaScript -->
        </div>

        <!-- Input Area -->
        <div class="prompt-container">
            <form class="prompt-form" id="promptForm">
                <input type="text" placeholder="Ask me anything..." class="prompt-input" id="promptInput" required>
                <div class="prompt-actions">
                    <button type="submit" id="send-prompts-btn" class="material-symbols-rounded">send</button>
                </div>
            </form>
            <p class="disclaimer-text">AI may occasionally generate inaccurate information</p>
        </div>
    </main>

    <script>
        // Real AI Connection
        const chatsContainer = document.getElementById("chatsContainer");
        const promptForm = document.getElementById("promptForm");
        const promptInput = document.getElementById("promptInput");
        const sendButton = document.getElementById("send-prompts-btn");

        // Groq AI Configuration
        const API_KEY = "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";
        const API_URL = "https://api.groq.com/openai/v1/chat/completions";
        const MODEL = "llama-3.1-8b-instant";

        let chatHistory = [];
        let isGenerating = false;

        // Create message element
        const createMessage = (text, isUser = false) => {
            const messageDiv = document.createElement("div");
            messageDiv.className = `message ${isUser ? "user-message" : "bot-message"}`;

            if (isUser) {
                messageDiv.innerHTML = `<p class="message-text">${escapeHtml(text)}</p>`;
            } else {
                messageDiv.innerHTML = `
                    <div class="avatar">AI</div>
                    <p class="message-text">${escapeHtml(text)}</p>
                `;
            }

            return messageDiv;
        };

        const escapeHtml = (text) => {
            const div = document.createElement("div");
            div.textContent = text;
            return div.innerHTML;
        };

        // Scroll to bottom
        const scrollToBottom = () => {
            chatsContainer.scrollTop = chatsContainer.scrollHeight;
        };

        // Show typing effect
        const typeMessage = (text, element) => {
            element.innerHTML = "";
            let index = 0;

            const typeInterval = setInterval(() => {
                if (index < text.length) {
                    element.innerHTML += text.charAt(index);
                    index++;
                    scrollToBottom();
                } else {
                    clearInterval(typeInterval);
                }
            }, 20);
        };

        // Real AI API Call
        const getAIResponse = async (userMessage) => {
            // Add to chat history
            chatHistory.push({
                role: "user",
                content: userMessage,
            });

            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${API_KEY}`,
                },
                body: JSON.stringify({
                    model: MODEL,
                    messages: [{
                            role: "system",
                            content: `You are a helpful and enthusiastic AI assistant. Please:
                            - Provide clear, detailed, and helpful responses
                            - Use emojis when appropriate to make conversations engaging
                            - Be friendly and professional
                            - If you don't know something, admit it honestly
                            - Format your responses for easy reading with proper paragraphs
                            - Provide practical examples when relevant
                            - Keep responses informative but concise`,
                        },
                        ...chatHistory.slice(-6), // Keep last 6 messages for context
                    ],
                    max_tokens: 1024,
                    temperature: 0.7,
                    stream: false,
                }),
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const data = await response.json();

            if (!data.choices || !data.choices[0].message.content) {
                throw new Error("Invalid response format");
            }

            const aiResponse = data.choices[0].message.content;

            // Add to chat history
            chatHistory.push({
                role: "assistant",
                content: aiResponse,
            });

            // Limit history size
            if (chatHistory.length > 10) {
                chatHistory = chatHistory.slice(-10);
            }

            return aiResponse;
        };

        // Handle form submission
        promptForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            const userMessage = promptInput.value.trim();
            if (!userMessage || isGenerating) return;

            // Clear input
            promptInput.value = "";
            isGenerating = true;
            sendButton.disabled = true;

            // Add user message
            const userMessageElement = createMessage(userMessage, true);
            chatsContainer.appendChild(userMessageElement);
            scrollToBottom();

            // Show loading message
            const loadingMessage = createMessage("Thinking...", false);
            loadingMessage.classList.add("loading");
            chatsContainer.appendChild(loadingMessage);
            scrollToBottom();

            try {
                // Get real AI response
                const aiResponse = await getAIResponse(userMessage);

                // Remove loading message
                loadingMessage.remove();

                // Add AI response with typing effect
                const aiMessageElement = createMessage("", false);
                chatsContainer.appendChild(aiMessageElement);
                const messageText = aiMessageElement.querySelector(".message-text");
                typeMessage(aiResponse, messageText);
            } catch (error) {
                console.error("AI Error:", error);
                loadingMessage.remove();
                const errorMessage = createMessage(
                    "Sorry, I'm having trouble connecting right now. Please try again in a moment! 🔧",
                    false
                );
                chatsContainer.appendChild(errorMessage);
            } finally {
                isGenerating = false;
                sendButton.disabled = false;
                promptInput.focus();
            }
        });

        // Quick suggestions click
        document.querySelectorAll(".suggestions-item").forEach((item) => {
            item.addEventListener("click", () => {
                const text = item.querySelector(".text").textContent;
                promptInput.value = text;
                promptInput.focus();

                // Auto-submit after short delay
                setTimeout(() => {
                    if (!isGenerating) {
                        promptForm.dispatchEvent(new Event("submit"));
                    }
                }, 100);
            });
        });

        // Enter key to send
        promptInput.addEventListener("keypress", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                promptForm.dispatchEvent(new Event("submit"));
            }
        });

        // Input validation
        promptInput.addEventListener("input", () => {
            sendButton.disabled = promptInput.value.trim() === "" || isGenerating;
        });

        // Initialize chat
        window.addEventListener("load", () => {
            promptInput.focus();

            // Welcome message
            const welcomeMessage = createMessage(
                "Hello! 👋 I'm your AI assistant powered by Groq. I can help you with programming, web development, design, career advice, or anything else you'd like to discuss! \n\nFeel free to ask me anything or click the suggestions above to get started. 🚀",
                false
            );
            chatsContainer.appendChild(welcomeMessage);

            // Add to chat history
            chatHistory.push({
                role: "assistant",
                content: "Hello! I'm your AI assistant. How can I help you today?",
            });

            scrollToBottom();
        });

        // Clear chat function
        window.clearChat = () => {
            chatsContainer.innerHTML = "";
            chatHistory = [];

            const welcomeMessage = createMessage(
                "Hello! 👋 Chat cleared. I'm ready to help you with a new conversation! What would you like to know?",
                false
            );
            chatsContainer.appendChild(welcomeMessage);

            chatHistory.push({
                role: "assistant",
                content: "Hello! Chat cleared. I'm ready to help you with a new conversation!",
            });

            promptInput.focus();
        };
    </script>
</body>

</html>