<?php
if (session_status() === PHP_SESSION_NONE) {
    // Mitigate session fixation by using secure settings where possible.
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

const ROLE_ARCHER = 'archer';
const ROLE_RECORDER = 'recorder';

$ACCESS_RULES = [
    ROLE_RECORDER => [
        'recorder_dashboard.php',
        'approve_practice_scores.php',
        'competition_management.php',
        'championship_management.php',
        'archer_round_management.php',
        'equivalent_rounds_management.php',
        'equipment_class_management.php',
    ],
    ROLE_ARCHER => [
        'dashboard.php',
        'practicescore.php',
        'myscore.php',
        'personalbest.php',
        'roundinfo.php',
        'compresult.php',
    ],
];

$PUBLIC_PAGES = [
    'index.php',
    'home.php',
    'about_us.php',
    'login.php',
    'register.php',
    'competitions.php',
    'news.php',
];


function current_page_name(): string {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if (!$path) {
        $path = $_SERVER['SCRIPT_NAME'] ?? '';
    }
    $base = basename($path);
    return $base ?: basename(__FILE__);
}

/** Get the appropriate dashboard page for a given role. */
function user_dashboard_for_role(string $role): string {
    return $role === ROLE_RECORDER ? 'recorder_dashboard.php' : 'dashboard.php';
}

/** Determine if a role may access a given page name (basename). */
function role_can_access_page(string $role, string $page, array $rules, array $publicPages): bool {
    $page = strtolower($page);
    if (in_array($page, array_map('strtolower', $publicPages), true)) {
        return true;
    }
    if (!isset($rules[$role])) return false;
    return in_array($page, array_map('strtolower', $rules[$role]), true);
}

/**
 * Is the user currently authenticated?
 */
function is_logged_in(): bool {
    return !empty($_SESSION['user_id']) && !empty($_SESSION['role']);
}

/**
 * Returns the current user's role (or null if not logged in)
 */
function current_role(): ?string {
    return $_SESSION['role'] ?? null;
}

/**
 * Log a user in by setting session variables and regenerating the session ID.
 * $role must be one of ROLE_ARCHER or ROLE_RECORDER.
 */
function login_user($userId, string $role): void {
    if (!in_array($role, [ROLE_ARCHER, ROLE_RECORDER], true)) {
        throw new InvalidArgumentException('Invalid role supplied to login_user');
    }
    // Regenerate session ID to prevent fixation
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }
    $_SESSION['user_id'] = $userId;
    $_SESSION['role'] = $role;
    $_SESSION['logged_in_at'] = time();
}

/**
 * Destroy the session and remove auth data
 */
function logout_user(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }
}

/**
 * Enforce access based on current page and the user's role/auth state.
 * If not authorized, redirect to login or to the user's own dashboard.
 */
function enforce_access(array $rules, array $publicPages): void {
    $page = strtolower(current_page_name());

    // Build a quick lookup by lowercased names (Windows dev is case-insensitive but many prod hosts are case-sensitive)
    $public = array_map('strtolower', $publicPages);

    $byRole = [];
    foreach ($rules as $role => $pages) {
        $byRole[$role] = array_map('strtolower', $pages);
    }

    // If page is public, allow
    if (in_array($page, $public, true)) {
        return;
    }

    // Determine which role (if any) owns this page
    $requiredRole = null;
    foreach ($byRole as $role => $pages) {
        if (in_array($page, $pages, true)) {
            $requiredRole = $role;
            break;
        }
    }

    // If page isn't in any list, treat as public by default (no-op)
    if ($requiredRole === null) {
        return;
    }

    // If not logged in, send to login with redirect back
    if (!is_logged_in()) {
        $target = 'login.php?redirect=' . urlencode($page);
        header('Location: ' . $target);
        exit;
    }

    // If logged in but wrong role, send them to their dashboard
    if (current_role() !== $requiredRole) {
        $dash = user_dashboard_for_role(current_role());
        header('Location: ' . $dash . '?denied=1');
        exit;
    }
}

// Auto-enforce when this file is included
enforce_access($ACCESS_RULES, $PUBLIC_PAGES);

?>
