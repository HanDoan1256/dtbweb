<?php
require_once 'manage_access.php'; // Changed from 'manage.php' to 'manage_access.php'
logout_user();
header("Location: login.php?message=" . urlencode("You have logged out successfully."));
exit;
?>