<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Competition Management</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Competition Management</h1>
    <form>
      <label>Competition Name:</label>
      <input type="text">
      <label>Date:</label>
      <input type="date">
      <label>Is Championship:</label>
      <input type="checkbox"> Yes
      <button type="submit">Add Competition</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>