<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Equipment & Class Management</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Equipment & Class Management</h1>

    <form>
      <h2>Add Equipment</h2>
      <label>Equipment Name:</label><input type="text">
      <button>Add Equipment</button>
    </form>

    <form>
      <h2>Update Class Rules</h2>
      <label>Class Name:</label><input type="text">
      <label>Class type:</label><select><option>A</option><option>B</option></select>
      <button>Update Class</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>