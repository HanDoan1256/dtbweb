<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Archer & Round Management</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Archer & Round Management</h1>
    <form>
      <h2>Add New Archer</h2>
      <label>Name:</label><input type="text">
      <label>DOB:</label><input type="date">
      <label>Gender:</label>
      <select><option>Male</option><option>Female</option></select>
      <button>Add Archer</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>