<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Approve Practice Scores</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Approve Practice Scores</h1>
    <table>
      <tr><th>Archer</th><th>Round</th><th>Date</th><th>Score</th><th>Action</th></tr>
      <tr><td>John Doe</td><td>WA70</td><td>2025-10-26</td><td>620</td>
          <td><button>Approve</button> <button>Reject</button></td></tr>
    </table>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>