<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Championship Management</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Championship Results</h1>
    <table>
      <tr><th>Competition</th><th>Archer</th><th>Score</th><th>Rank</th></tr>
    </table>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>