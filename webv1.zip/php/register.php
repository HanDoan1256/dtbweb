<?php  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register | Archery Portal</title>
  <link rel="stylesheet" href="styles.css">
  <script type="module" src="supabase.js"></script>
</head>
<body>
  <?php include 'header.inc'; ?>

  <main>
    <h1>Register Recorder</h1>
    <form>
      <label>Full Name:</label>
      <input type="text" required>

      <label>Email:</label>
      <input type="email" required>

      <label>Password:</label>
      <input type="password" required>

      <button type="submit">Create Account</button>
    </form>
  </main>

  <?php include 'footer.inc'; ?>
</body>
</html>